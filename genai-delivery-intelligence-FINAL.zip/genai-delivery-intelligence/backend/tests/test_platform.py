"""Core tests. Use a temporary database so the project database is never touched."""
import copy
import hashlib
import os
import tempfile
import unittest

from app.database import init_db
from app.genai import decision_assistant
from app.services import (dependency_service, portfolio_service, report_service, risk_service,
                          scope_service, simulation_service)
from app.services.snapshot import load_snapshot

TMP = tempfile.mkdtemp(prefix="deliv_test_")
DB = os.path.join(TMP, "test.db")


def setUpModule():
    init_db(DB)


def _snap():
    return load_snapshot(DB)


def _sha(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


class ReconciliationTests(unittest.TestCase):
    def test_all_original_inputs_reconcile(self):
        failed = [c for c in portfolio_service.reconcile(_snap()) if not c["passed"]]
        self.assertEqual(failed, [], f"Mismatched checks: {failed}")

    def test_key_counts(self):
        ov = portfolio_service.overview(_snap())
        self.assertEqual(ov["milestones_total"], 24)
        self.assertEqual(ov["milestones_on_time"], 17)
        self.assertEqual(ov["open_dependencies"], 17)
        self.assertEqual(ov["overdue_dependencies"], 6)
        self.assertEqual(ov["pending_change_requests"], 14)
        self.assertEqual(sorted(ov["overallocated_specialists"]), ["SP-02", "SP-03"])
        self.assertEqual(ov["portfolio_margin_pct"], 17.0)

    def test_planned_margin_not_mixed_with_actual(self):
        ov = portfolio_service.overview(_snap())
        self.assertEqual(ov["planned_margin_pct"], 22.0)
        self.assertNotEqual(ov["planned_margin_pct"], ov["portfolio_margin_pct"])


class AnalyticsTests(unittest.TestCase):
    def test_program_risk_ranking(self):
        ranked = risk_service.all_program_risks(_snap())
        self.assertEqual(ranked[0]["program_id"], "PRG-001")
        self.assertEqual(ranked[0]["level"], "HIGH")
        self.assertTrue(all(r["evidence"] for r in ranked[:3]))

    def test_dependency_escalation(self):
        items = {d["dependency_id"]: d for d in dependency_service.overdue_dependencies(_snap())}
        self.assertEqual(len(items), 6)
        self.assertEqual(items["DEP-03"]["escalation_priority"], "P1 CRITICAL")
        self.assertEqual(items["DEP-05"]["escalation_priority"], "P3 MEDIUM")

    def test_scope_classification_covers_all_pending(self):
        rows = scope_service.assess(_snap())
        self.assertEqual(len(rows), 14)
        self.assertEqual(next(r for r in rows if r["change_id"] == "CR-01")["recommendation"], "DEFER")
        self.assertTrue(all(r["approval_required"] for r in rows))


class ReallocationTests(unittest.TestCase):
    def test_architect_overload_has_feasible_option_without_contractor(self):
        opts = simulation_service.reallocation_options(_snap(), "SP-02")
        self.assertTrue(opts)
        self.assertTrue(opts[0]["feasible"])
        self.assertFalse(opts[0]["requires_contractor"])
        self.assertTrue(opts[0]["preferred"])

    def test_test_lead_overload_needs_contractor_for_residual(self):
        opts = simulation_service.reallocation_options(_snap(), "SP-03")
        self.assertTrue(any(o["requires_contractor"] for o in opts))
        best = opts[0]
        self.assertTrue(best["requires_contractor"])
        self.assertGreater(best["indicative_cost_impact_usd"], 0)


class SimulationSafetyTests(unittest.TestCase):
    def test_simulation_never_modifies_snapshot_or_database(self):
        snap = _snap()
        before_snap = copy.deepcopy(snap)
        before_hash = _sha(DB)
        simulation_service.simulate(snap, {"type": "DELAY_MILESTONE",
                                           "params": {"milestone_id": "M-005", "days": 14}})
        simulation_service.reallocation_options(snap, "SP-02")
        self.assertEqual(snap, before_snap)
        self.assertEqual(_sha(DB), before_hash)

    def test_delay_scenario_raises_risk_and_reports_assumptions(self):
        res = simulation_service.simulate(_snap(), {"type": "DELAY_MILESTONE",
                                                    "params": {"milestone_id": "M-005", "days": 14}})
        self.assertFalse(res["baseline_modified"])
        self.assertGreater(res["risk_after"]["PRG-001"]["score"], res["risk_before"]["PRG-001"]["score"])
        self.assertTrue(res["assumptions"])

    def test_unknown_scenario_rejected(self):
        with self.assertRaises(ValueError):
            simulation_service.simulate(_snap(), {"type": "DELETE_EVERYTHING", "params": {}})


class GenAISafetyTests(unittest.TestCase):
    def test_answers_are_labelled_and_policy_gap_is_declared(self):
        ans = decision_assistant.answer(_snap(), "Which specialists are overloaded?")
        self.assertTrue(all(e.startswith("FACT") for e in ans["supporting_evidence"]))
        self.assertTrue(all(a.startswith("AI ANALYSIS") for a in ans["recommended_actions"]))
        self.assertIn("No policy documents", ans["policy_references"][0])
        self.assertIn("Requires authorised approval", ans["approval_requirements"])

    def test_unsupported_question_is_declined_not_invented(self):
        ans = decision_assistant.answer(_snap(), "What is the CEO's favourite colour?")
        self.assertIn("cannot answer", ans["direct_answer"])
        self.assertEqual(ans["supporting_evidence"], [])


class ReportTests(unittest.TestCase):
    def test_reports_generated_from_same_snapshot(self):
        out = tempfile.mkdtemp(prefix="deliv_reports_")
        paths = report_service.build_all(_snap(), out)
        for name, p in paths.items():
            self.assertTrue(os.path.getsize(p) > 1000, f"{name} looks empty")
        plan = report_service.build_recovery_plan(_snap())
        self.assertTrue(all(a["status_label"].startswith("TARGET") for a in plan))
        self.assertTrue(all(a["owner"] and a["start_date"] and a["target_completion_date"] for a in plan))


if __name__ == "__main__":
    unittest.main()
