"""Human-in-the-loop approval records. AI actors can create recommendations but can never decide them."""
import json
from datetime import datetime, timezone

from app.database import log_audit
from app.security import has_permission

AI_ACTOR = "ai-agent"
DECISIONS = {"APPROVED", "REJECTED"}


def create(conn, kind, entity, payload, summary, source, created_by):
    if created_by == AI_ACTOR and not source.startswith("AI"):
        raise ValueError("AI-created records must carry an AI source label")
    cur = conn.execute(
        "INSERT INTO approval_records(kind, entity, payload, summary, source, status, created_by, created_at) "
        "VALUES (?,?,?,?,?, 'PENDING', ?, ?)",
        (kind, entity, json.dumps(payload, sort_keys=True), summary, source, created_by,
         datetime.now(timezone.utc).isoformat()))
    log_audit(conn, created_by, "RECOMMENDATION_CREATED", entity, f"{kind}: {summary}")
    conn.commit()
    return cur.lastrowid


def decide(conn, user, approval_id, decision, comment=""):
    if user["username"] == AI_ACTOR:
        raise PermissionError("AI actors cannot decide approvals")
    if not has_permission(user, "approve"):
        raise PermissionError("Your role cannot record approval decisions")
    if decision not in DECISIONS:
        raise ValueError("decision must be APPROVED or REJECTED")
    row = conn.execute("SELECT * FROM approval_records WHERE id = ?", (approval_id,)).fetchone()
    if row is None:
        raise KeyError(f"approval {approval_id} not found")
    if row["status"] != "PENDING":
        raise ValueError(f"approval {approval_id} already {row['status']}")
    now = datetime.now(timezone.utc).isoformat()
    conn.execute("UPDATE approval_records SET status=?, decided_by=?, decided_at=?, decision_comment=? WHERE id=?",
                 (decision, user["username"], now, comment[:500], approval_id))
    log_audit(conn, user["username"], f"DECISION_{decision}", row["entity"], f"approval {approval_id}")
    conn.commit()
    return {"id": approval_id, "status": decision, "decided_by": user["username"], "decided_at": now,
            "note": "Decision recorded. No baseline record was changed automatically."}


def list_items(conn, status=None):
    if status:
        rows = conn.execute("SELECT * FROM approval_records WHERE status = ? ORDER BY id", (status,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM approval_records ORDER BY id").fetchall()
    out = []
    for r in rows:
        item = dict(r)
        item["payload"] = json.loads(item["payload"])
        out.append(item)
    return out
