"""SQLite schema and seeding. PostgreSQL is not implemented: no database driver can be installed in the build environment."""
import os
import sqlite3
from datetime import datetime, timezone

from app import config
from app.data import synthetic_portfolio as d
from app import security

SCHEMA = """
CREATE TABLE customers(customer_id TEXT PRIMARY KEY, name TEXT NOT NULL, sector TEXT);
CREATE TABLE programs(program_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL REFERENCES customers(customer_id),
    name TEXT NOT NULL, program_type TEXT, revenue_usd REAL NOT NULL, cost_usd REAL NOT NULL);
CREATE TABLE milestones(milestone_id TEXT PRIMARY KEY, program_id TEXT NOT NULL REFERENCES programs(program_id),
    name TEXT NOT NULL, planned_date TEXT NOT NULL, forecast_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('ON_TIME','LATE','AT_RISK')));
CREATE TABLE specialists(specialist_id TEXT PRIMARY KEY, name TEXT NOT NULL, role TEXT NOT NULL,
    is_key_role INTEGER NOT NULL CHECK (is_key_role IN (0,1)));
CREATE TABLE resource_allocations(specialist_id TEXT NOT NULL REFERENCES specialists(specialist_id),
    program_id TEXT NOT NULL REFERENCES programs(program_id), allocation_pct REAL NOT NULL CHECK (allocation_pct >= 0),
    PRIMARY KEY(specialist_id, program_id));
CREATE TABLE dependencies(dependency_id TEXT PRIMARY KEY, provider_program_id TEXT NOT NULL REFERENCES programs(program_id),
    dependent_program_id TEXT NOT NULL REFERENCES programs(program_id), description TEXT, owner TEXT,
    due_date TEXT NOT NULL, downstream_milestone_id TEXT REFERENCES milestones(milestone_id),
    status TEXT NOT NULL CHECK (status IN ('OPEN','CLOSED')));
CREATE TABLE change_requests(change_id TEXT PRIMARY KEY, program_id TEXT NOT NULL REFERENCES programs(program_id),
    title TEXT NOT NULL, effort_days REAL NOT NULL, schedule_impact_days REAL NOT NULL, skills TEXT,
    dependency_impact INTEGER NOT NULL, commitment_conflict INTEGER NOT NULL, status TEXT NOT NULL);
CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, actor TEXT NOT NULL,
    action TEXT NOT NULL, entity TEXT, detail TEXT);
CREATE TABLE approval_records(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, entity TEXT NOT NULL,
    payload TEXT NOT NULL, summary TEXT NOT NULL, source TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED')),
    created_by TEXT NOT NULL, created_at TEXT NOT NULL, decided_by TEXT, decided_at TEXT, decision_comment TEXT);
CREATE TABLE users(user_id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT,
    password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('VIEWER','ANALYST','APPROVER','ADMIN')),
    active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(user_id),
    created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE TABLE agent_runs(run_id TEXT PRIMARY KEY, question TEXT, status TEXT NOT NULL, state_json TEXT NOT NULL,
    created_by TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE kb_documents(doc_id TEXT PRIMARY KEY, source_file TEXT NOT NULL, title TEXT, doc_type TEXT,
    scope TEXT, category TEXT, status TEXT, effective_date TEXT, version TEXT, sha256 TEXT NOT NULL);
CREATE TABLE kb_chunks(chunk_id TEXT PRIMARY KEY, doc_id TEXT NOT NULL REFERENCES kb_documents(doc_id),
    section TEXT, text TEXT NOT NULL, quarantined INTEGER NOT NULL DEFAULT 0, embedding BLOB NOT NULL);
"""


def connect(path=None):
    conn = sqlite3.connect(path or config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def log_audit(conn, actor, action, entity, detail=""):
    conn.execute(
        "INSERT INTO audit_log(ts, actor, action, entity, detail) VALUES (?,?,?,?,?)",
        (datetime.now(timezone.utc).isoformat(), actor, action, entity, detail),
    )


def init_db(path=None):
    """Create a fresh database seeded with the SYNTHETIC portfolio. Replaces any existing file at path."""
    path = path or config.DATABASE_PATH
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    if os.path.exists(path):
        os.remove(path)
    conn = connect(path)
    try:
        conn.executescript(SCHEMA)
        conn.executemany("INSERT INTO customers VALUES (?,?,?)", d.CUSTOMERS)
        conn.executemany("INSERT INTO programs VALUES (?,?,?,?,?,?)", d.PROGRAMS)
        conn.executemany("INSERT INTO milestones VALUES (?,?,?,?,?,?)", d.MILESTONES)
        conn.executemany("INSERT INTO specialists VALUES (?,?,?,?)", d.SPECIALISTS)
        conn.executemany("INSERT INTO resource_allocations VALUES (?,?,?)", d.ALLOCATIONS)
        conn.executemany("INSERT INTO dependencies VALUES (?,?,?,?,?,?,?,?)", d.DEPENDENCIES)
        conn.executemany(
            "INSERT INTO change_requests VALUES (?,?,?,?,?,?,?,?,?)",
            [(c[0], c[1], c[2], c[3], c[4], c[5], int(c[6]), int(c[7]), c[8]) for c in d.CHANGE_REQUESTS],
        )
        log_audit(conn, "system", "SEED_SYNTHETIC_DATA", "portfolio",
                  "Fictional dataset reconciled to ORIGINAL_BASELINE inputs")
        creds = security.seed_demo_users(conn)
        conn.commit()
    finally:
        conn.close()
    return path, creds
