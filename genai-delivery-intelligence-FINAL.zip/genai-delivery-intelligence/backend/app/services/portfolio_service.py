"""Portfolio metrics and baseline reconciliation. Deterministic only."""
from app import config
from app.data import synthetic_portfolio as d
from app.services import resource_service, risk_service


def _pct(n, total):
    return round(100.0 * n / total, 1) if total else 0.0


def overview(snap):
    ms = snap["milestones"]
    on_time = sum(1 for m in ms if m["status"] == "ON_TIME")
    open_deps = [x for x in snap["dependencies"] if x["status"] == "OPEN"]
    overdue = [x for x in open_deps if x["overdue"]]
    pending = [c for c in snap["change_requests"] if c["status"] == "PENDING"]
    over = [s for s in resource_service.specialist_loads(snap) if s["overallocated_pct"] > 0]
    revenue = sum(p["revenue_usd"] for p in snap["programs"])
    cost = sum(p["cost_usd"] for p in snap["programs"])
    return {
        "customers": len(snap["customers"]),
        "programs": len(snap["programs"]),
        "milestones_total": len(ms),
        "milestones_on_time": on_time,
        "milestone_on_time_pct": _pct(on_time, len(ms)),
        "open_dependencies": len(open_deps),
        "overdue_dependencies": len(overdue),
        "pending_change_requests": len(pending),
        "overallocated_specialists": [s["specialist_id"] for s in over],
        "overallocated_detail": {s["specialist_id"]: s["total_pct"] for s in over},
        "revenue_usd": revenue,
        "cost_usd": cost,
        "portfolio_margin_pct": _pct(revenue - cost, revenue),
        "planned_margin_pct": config.PLANNED_MARGIN_PCT,
    }


def _check(name, expected, actual):
    return {"check": name, "expected": expected, "actual": actual, "passed": expected == actual}


def reconcile(snap):
    """Verify the synthetic dataset reproduces the ORIGINAL_BASELINE inputs exactly."""
    ov = overview(snap)
    loads = resource_service.specialist_loads(snap)
    key_peak = max([s["total_pct"] for s in loads if s["is_key_role"]] or [0])
    b = d.ORIGINAL_BASELINE
    return [
        _check("Portfolio size (programs)", b["portfolio_size_programs"], ov["programs"]),
        _check("Enterprise customers", b["enterprise_customers"], ov["customers"]),
        _check("Milestones on time (%, rounded)", b["milestones_on_time_pct"], round(ov["milestone_on_time_pct"])),
        _check("Open cross-team dependencies", b["open_dependencies"], ov["open_dependencies"]),
        _check("Overdue dependencies", b["overdue_dependencies"], ov["overdue_dependencies"]),
        _check("Overallocated key specialist roles", b["overallocated_key_specialist_roles"],
               sum(1 for s in loads if s["is_key_role"] and s["overallocated_pct"] > 0)),
        _check("Current specialist allocation (peak %)", b["current_specialist_allocation_pct"], key_peak),
        _check("Pending change requests", b["pending_change_requests"], ov["pending_change_requests"]),
        _check("Actual portfolio margin (%, rounded)", b["actual_portfolio_margin_pct"],
               round(ov["portfolio_margin_pct"])),
        _check("Planned portfolio margin (%)", b["planned_portfolio_margin_pct"], config.PLANNED_MARGIN_PCT),
    ]


def customer_performance(snap):
    rows = []
    for c in snap["customers"]:
        pids = {p["program_id"] for p in snap["programs"] if p["customer_id"] == c["customer_id"]}
        ms = [m for m in snap["milestones"] if m["program_id"] in pids]
        on = sum(1 for m in ms if m["status"] == "ON_TIME")
        progs = [p for p in snap["programs"] if p["program_id"] in pids]
        rev = sum(p["revenue_usd"] for p in progs)
        cost = sum(p["cost_usd"] for p in progs)
        risks = [risk_service.program_risk(snap, pid) for pid in sorted(pids)]
        rows.append({
            "customer_id": c["customer_id"], "customer": c["name"], "programs": sorted(pids),
            "milestone_on_time_pct": _pct(on, len(ms)), "margin_pct": _pct(rev - cost, rev),
            "max_program_risk": max(r["score"] for r in risks),
        })
    return sorted(rows, key=lambda r: -r["max_program_risk"])


def program_status(snap):
    rows = []
    for p in snap["programs"]:
        pid = p["program_id"]
        ms = [m for m in snap["milestones"] if m["program_id"] == pid]
        on = sum(1 for m in ms if m["status"] == "ON_TIME")
        open_deps = [x for x in snap["dependencies"] if x["status"] == "OPEN"
                     and pid in (x["provider_program_id"], x["dependent_program_id"])]
        risk = risk_service.program_risk(snap, pid)
        rows.append({
            "program_id": pid, "name": p["name"], "customer_id": p["customer_id"],
            "milestones": len(ms), "milestones_on_time": on,
            "milestone_on_time_pct": _pct(on, len(ms)),
            "revenue_usd": p["revenue_usd"], "cost_usd": p["cost_usd"],
            "margin_pct": _pct(p["revenue_usd"] - p["cost_usd"], p["revenue_usd"]),
            "open_dependencies": len(open_deps),
            "overdue_dependencies": sum(1 for x in open_deps if x["overdue"]),
            "risk_score": risk["score"], "risk_level": risk["level"],
        })
    return rows
