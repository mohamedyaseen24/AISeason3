"""Transparent, configurable deterministic risk scoring. The LLM never sets these numbers."""
from app import config
from app.services import resource_service


def _level(score):
    if score >= config.RISK_HIGH_THRESHOLD:
        return "HIGH"
    if score >= config.RISK_MEDIUM_THRESHOLD:
        return "MEDIUM"
    return "LOW"


def program_risk(snap, program_id):
    ms = [m for m in snap["milestones"] if m["program_id"] == program_id]
    slipping = [m for m in ms if m["status"] != "ON_TIME"]
    milestone_pts = round(config.W_MILESTONE_SLIP * len(slipping) / len(ms), 1) if ms else 0.0

    overdue = [d for d in snap["dependencies"] if d["overdue"]
               and program_id in (d["provider_program_id"], d["dependent_program_id"])]
    dep_pts = min(config.W_OVERDUE_DEP_EACH * len(overdue), config.W_OVERDUE_DEP_CAP)

    loads = {s["specialist_id"]: s for s in resource_service.specialist_loads(snap)}
    prog_specs = sorted({a["specialist_id"] for a in snap["allocations"] if a["program_id"] == program_id})
    over = [sid for sid in prog_specs if loads[sid]["overallocated_pct"] > 0]
    warn = [sid for sid in prog_specs if loads[sid]["total_pct"] >= config.CAPACITY_WARN_PCT]
    cap_pts = config.W_CAPACITY_OVER if over else (config.W_CAPACITY_WARN if warn else 0)

    crs = [c for c in snap["change_requests"]
           if c["program_id"] == program_id and c["status"] in ("PENDING", "SIMULATED_APPROVED")]
    sched = sum(c["schedule_impact_days"] for c in crs)
    scope_pts = round(min(config.W_SCOPE * sched / config.SCOPE_SATURATION_DAYS, config.W_SCOPE), 1)

    score = round(milestone_pts + dep_pts + cap_pts + scope_pts, 1)
    evidence = []
    if slipping:
        evidence.append(f"FACT: {len(slipping)} of {len(ms)} milestones not ON_TIME "
                        f"({', '.join(m['milestone_id'] for m in slipping)})")
    if overdue:
        evidence.append(f"FACT: {len(overdue)} overdue open dependencies involve this program "
                        f"({', '.join(d['dependency_id'] for d in overdue)})")
    if over:
        evidence.append(f"FACT: specialist(s) above 100% allocation on this program: {', '.join(over)}")
    elif warn:
        evidence.append(f"FACT: specialist(s) at or above {config.CAPACITY_WARN_PCT}%: {', '.join(warn)}")
    if crs:
        evidence.append(f"FACT: {len(crs)} pending or simulated change requests add {sched:g} schedule days")

    return {
        "program_id": program_id,
        "score": score,
        "level": _level(score),
        "components": {"milestone_slip": milestone_pts, "overdue_dependencies": dep_pts,
                       "capacity": cap_pts, "scope": scope_pts},
        "overallocated_specialists": over,
        "evidence": evidence,
    }


def all_program_risks(snap):
    rows = [program_risk(snap, p["program_id"]) for p in snap["programs"]]
    return sorted(rows, key=lambda r: (-r["score"], r["program_id"]))
