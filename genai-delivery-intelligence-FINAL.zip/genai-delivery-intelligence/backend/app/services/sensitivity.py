"""Sensitivity analysis of the risk weights: does the program ranking survive +/-25% changes?
This is NOT calibration. Calibration needs historical delivery outcomes, which this project does not have."""
from app import config
from app.services import risk_service

WEIGHTS = ["W_MILESTONE_SLIP", "W_OVERDUE_DEP_EACH", "W_CAPACITY_OVER", "W_SCOPE"]


def _ranking(snap):
    return [(r["program_id"], r["score"], r["level"]) for r in risk_service.all_program_risks(snap)]


def run(snap, factors=(0.75, 1.25)):
    base = _ranking(snap)
    base_order = [p for p, _, _ in base]
    rows = []
    for weight in WEIGHTS:
        original = getattr(config, weight)
        for factor in factors:
            setattr(config, weight, original * factor)
            try:
                ranked = _ranking(snap)
            finally:
                setattr(config, weight, original)
            order = [p for p, _, _ in ranked]
            rows.append({
                "weight": weight, "factor": factor, "ranking": order,
                "top_program_unchanged": order[0] == base_order[0],
                "ranking_unchanged": order == base_order,
                "level_changes": sum(1 for (_, _, l), (_, _, bl) in zip(ranked, base) if l != bl),
            })
    return {
        "baseline_ranking": [{"program_id": p, "score": s, "level": l} for p, s, l in base],
        "scenarios": rows,
        "top_program_stable_in": sum(r["top_program_unchanged"] for r in rows),
        "ranking_stable_in": sum(r["ranking_unchanged"] for r in rows),
        "total_scenarios": len(rows),
        "note": "Sensitivity analysis only. Weights are judgement-based and not calibrated to outcomes.",
    }
