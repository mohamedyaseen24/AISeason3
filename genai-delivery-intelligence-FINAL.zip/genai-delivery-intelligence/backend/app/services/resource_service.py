"""Deterministic specialist capacity logic. Pure functions over a snapshot."""
import copy
from collections import defaultdict

from app import config


def role_family(role):
    r = role.lower()
    if "architect" in r:
        return "architect"
    if "test" in r or "qa" in r:
        return "test"
    return r


def specialist_loads(snap):
    by_spec = defaultdict(list)
    for a in snap["allocations"]:
        by_spec[a["specialist_id"]].append({"program_id": a["program_id"], "pct": float(a["allocation_pct"])})
    loads = []
    for s in snap["specialists"]:
        items = sorted(by_spec.get(s["specialist_id"], []), key=lambda x: x["program_id"])
        total = sum(i["pct"] for i in items)
        loads.append({
            "specialist_id": s["specialist_id"],
            "name": s["name"],
            "role": s["role"],
            "is_key_role": bool(s["is_key_role"]),
            "allocations": items,
            "total_pct": total,
            "free_pct": max(0.0, config.CAPACITY_PER_SPECIALIST_PCT - total),
            "overallocated_pct": max(0.0, total - config.CAPACITY_PER_SPECIALIST_PCT),
        })
    return loads


def apply_move(snap, from_id, to_id, program_id, pct):
    """Return a NEW snapshot with pct of program_id work moved between specialists."""
    new = copy.deepcopy(snap)
    src = next((a for a in new["allocations"]
                if a["specialist_id"] == from_id and a["program_id"] == program_id), None)
    if src is None or src["allocation_pct"] < pct:
        raise ValueError(f"{from_id} has insufficient allocation on {program_id} to move {pct}%")
    src["allocation_pct"] -= pct
    new["allocations"] = [a for a in new["allocations"] if a["allocation_pct"] > 0]
    dst = next((a for a in new["allocations"]
                if a["specialist_id"] == to_id and a["program_id"] == program_id), None)
    if dst:
        dst["allocation_pct"] += pct
    else:
        new["allocations"].append({"specialist_id": to_id, "program_id": program_id, "allocation_pct": pct})
    return new
