"""What-if simulation on an in-memory copy of the snapshot.
Numbers are deterministic. Nothing here writes to the database or changes the approved baseline."""
import copy
from datetime import date, timedelta

from app import config
from app.services import portfolio_service, resource_service, risk_service
from app.services import snapshot as snap_svc

SUPPORTED_TYPES = ("MOVE_ALLOCATION", "DELAY_MILESTONE", "RESOLVE_DEPENDENCY",
                   "APPROVE_CHANGE_REQUESTS", "ADD_CONTRACTOR", "COMPOSITE")

STANDARD_ASSUMPTIONS = [
    "Costs are indicative, using the blended or contractor day rates in configuration.",
    "Risk scores use the same deterministic framework as the baseline; no new evidence is assumed.",
    "No baseline record is modified: the simulation runs on a discarded in-memory copy.",
]


def _find(items, key, value):
    for item in items:
        if item[key] == value:
            return item
    raise KeyError(f"{key} '{value}' not found")


def _apply_step(snap, step, assumptions):
    kind = step["type"]
    p = step.get("params", {})
    if kind == "MOVE_ALLOCATION":
        assumptions.append("Recipient delivers at the same productivity as the source; ramp-up and knowledge "
                           "transfer are not quantified.")
        return resource_service.apply_move(snap, p["from_specialist"], p["to_specialist"],
                                           p["program_id"], float(p["pct"]))
    new = copy.deepcopy(snap)
    if kind == "DELAY_MILESTONE":
        m = _find(new["milestones"], "milestone_id", p["milestone_id"])
        m["forecast_date"] = (date.fromisoformat(m["forecast_date"]) + timedelta(days=int(p["days"]))).isoformat()
        if m["status"] == "ON_TIME":
            m["status"] = "LATE"
        assumptions.append("Delay is applied to the milestone forecast only; knock-on effects on other milestones "
                           "are not modelled automatically.")
    elif kind == "RESOLVE_DEPENDENCY":
        dep = _find(new["dependencies"], "dependency_id", p["dependency_id"])
        dep["status"] = "CLOSED"
        assumptions.append(f"Dependency treated as closed on {p.get('resolve_on', snap['as_of'].isoformat())}; "
                           "downstream forecasts are not changed automatically.")
    elif kind == "APPROVE_CHANGE_REQUESTS":
        billable = float(p.get("billable_pct", 0))
        for cid in p["change_ids"]:
            cr = _find(new["change_requests"], "change_id", cid)
            cr["status"] = "SIMULATED_APPROVED"
            cost = cr["effort_days"] * config.BLENDED_RATE_USD_PER_DAY
            prog = _find(new["programs"], "program_id", cr["program_id"])
            prog["cost_usd"] += cost
            prog["revenue_usd"] += cost * billable / 100
        assumptions.append(f"Approved changes costed at the blended rate; billable share assumed {billable:g}%.")
    elif kind == "ADD_CONTRACTOR":
        n = sum(1 for s in new["specialists"] if s["specialist_id"].startswith("CTR-")) + 1
        cid = f"CTR-{n:02d}"
        new["specialists"].append({"specialist_id": cid, "name": f"Contractor {n:02d} ({p['role']})",
                                   "role": p["role"], "is_key_role": False})
        pct = float(p["pct"])
        days = int(p.get("days", 60))
        if p.get("from_specialist"):
            new = resource_service.apply_move(new, p["from_specialist"], cid, p["program_id"], pct)
        else:
            new["allocations"].append({"specialist_id": cid, "program_id": p["program_id"], "allocation_pct": pct})
        prog = _find(new["programs"], "program_id", p["program_id"])
        prog["cost_usd"] += days * config.CONTRACTOR_RATE_USD_PER_DAY * pct / 100
        assumptions.append(f"Contractor cost uses the contractor day rate for {days} working days at {pct:g}%; "
                           "onboarding and ramp-up are not modelled.")
    else:
        raise ValueError(f"Unsupported step type: {kind}")
    return new


def _evaluate(snap):
    risks = {p["program_id"]: risk_service.program_risk(snap, p["program_id"]) for p in snap["programs"]}
    loads = {s["specialist_id"]: s for s in resource_service.specialist_loads(snap)}
    return risks, loads, portfolio_service.overview(snap)


def simulate(snap, scenario):
    """Run a scenario and return before/after outcomes. Input snap is never mutated."""
    if scenario.get("type") not in SUPPORTED_TYPES:
        raise ValueError(f"Unknown scenario type: {scenario.get('type')}")
    steps = scenario["steps"] if scenario["type"] == "COMPOSITE" else [scenario]
    assumptions = []
    new = copy.deepcopy(snap)
    for step in steps:
        new = _apply_step(new, step, assumptions)
    new = snap_svc.refresh(new)

    b_risk, b_loads, b_ov = _evaluate(snap)
    a_risk, a_loads, a_ov = _evaluate(new)
    b_cost = {p["program_id"]: p["cost_usd"] for p in snap["programs"]}
    a_cost = {p["program_id"]: p["cost_usd"] for p in new["programs"]}
    prog_info = {p["program_id"]: p for p in snap["programs"]}
    cust_name = {c["customer_id"]: c["name"] for c in snap["customers"]}

    affected = []
    for pid in b_risk:
        delta = a_cost[pid] - b_cost[pid]
        if delta or b_risk[pid]["score"] != a_risk[pid]["score"]:
            affected.append({
                "program_id": pid, "program_name": prog_info[pid]["name"],
                "customer": cust_name[prog_info[pid]["customer_id"]],
                "risk_before": b_risk[pid]["score"], "risk_after": a_risk[pid]["score"],
                "level_before": b_risk[pid]["level"], "level_after": a_risk[pid]["level"],
                "cost_delta_usd": round(delta, 2),
            })

    util_changes = []
    for sid, load in a_loads.items():
        before = b_loads[sid]["total_pct"] if sid in b_loads else 0.0
        if before != load["total_pct"]:
            util_changes.append({"specialist_id": sid, "before_pct": before, "after_pct": load["total_pct"]})

    ms_before = {m["milestone_id"]: m for m in snap["milestones"]}
    ms_changes = [{"milestone_id": m["milestone_id"], "before_forecast": ms_before[m["milestone_id"]]["forecast_date"],
                   "after_forecast": m["forecast_date"], "before_status": ms_before[m["milestone_id"]]["status"],
                   "after_status": m["status"]}
                  for m in new["milestones"]
                  if m != ms_before[m["milestone_id"]] and (m["forecast_date"] != ms_before[m["milestone_id"]]["forecast_date"]
                                                            or m["status"] != ms_before[m["milestone_id"]]["status"])]

    return {
        "scenario_type": scenario["type"],
        "label": "SIMULATION - not an approved change",
        "baseline_modified": False,
        "affected_programs": affected,
        "risk_before": {k: {"score": v["score"], "level": v["level"]} for k, v in b_risk.items()},
        "risk_after": {k: {"score": v["score"], "level": v["level"]} for k, v in a_risk.items()},
        "portfolio_risk_before_total": round(sum(v["score"] for v in b_risk.values()), 1),
        "portfolio_risk_after_total": round(sum(v["score"] for v in a_risk.values()), 1),
        "utilization_changes": util_changes,
        "milestone_changes": ms_changes,
        "overdue_dependencies": {"before": b_ov["overdue_dependencies"], "after": a_ov["overdue_dependencies"]},
        "overallocated_after": sorted(sid for sid, l in a_loads.items() if l["overallocated_pct"] > 0),
        "indicative_cost_impact_usd": round(sum(a_cost[p] - b_cost[p] for p in b_cost), 2),
        "margin_before_pct": b_ov["portfolio_margin_pct"],
        "margin_after_pct": a_ov["portfolio_margin_pct"],
        "customer_commitment_impact": [
            f"{a['customer']} - {a['program_name']}: risk {a['risk_before']} -> {a['risk_after']} "
            f"({a['level_before']} -> {a['level_after']})" for a in affected],
        "assumptions": assumptions + STANDARD_ASSUMPTIONS,
        "approval_required": True,
    }


def reallocation_options(snap, specialist_id):
    """Feasible ways to clear an overallocation, ranked. Options are simulated, never applied."""
    loads = {s["specialist_id"]: s for s in resource_service.specialist_loads(snap)}
    if specialist_id not in loads:
        raise KeyError(f"Unknown specialist {specialist_id}")
    src = loads[specialist_id]
    excess = src["overallocated_pct"]
    if excess <= 0:
        return []
    family = resource_service.role_family(src["role"])
    candidates = [l for l in loads.values()
                  if l["specialist_id"] != specialist_id and not l["specialist_id"].startswith("CTR-")
                  and l["free_pct"] > 0 and resource_service.role_family(l["role"]) == family]

    proposals = []
    for alloc in src["allocations"]:
        pid = alloc["program_id"]
        need = min(excess, alloc["pct"])
        for cand in candidates:
            absorb = min(need, cand["free_pct"])
            residual = round(excess - absorb, 2)
            steps = [{"type": "MOVE_ALLOCATION", "params": {
                "from_specialist": specialist_id, "to_specialist": cand["specialist_id"],
                "program_id": pid, "pct": absorb}}]
            desc = f"Move {absorb:g}% of {pid} work from {specialist_id} to {cand['specialist_id']} ({cand['name']})"
            if residual > 0:
                steps.append({"type": "ADD_CONTRACTOR", "params": {
                    "role": src["role"], "program_id": pid, "pct": residual, "days": 60,
                    "from_specialist": specialist_id}})
                desc += f"; contractor covers remaining {residual:g}%"
            proposals.append((desc, steps, residual > 0))
        proposals.append((f"Add contractor for {excess:g}% on {pid} (no internal move)",
                          [{"type": "ADD_CONTRACTOR", "params": {
                              "role": src["role"], "program_id": pid, "pct": excess, "days": 60,
                              "from_specialist": specialist_id}}], True))

    results = []
    for desc, steps, needs_contractor in proposals:
        try:
            sim = simulate(snap, {"type": "COMPOSITE", "steps": steps})
        except ValueError:
            continue
        involved = {specialist_id} | {s["params"]["to_specialist"] for s in steps if s["type"] == "MOVE_ALLOCATION"}
        results.append({
            "description": desc,
            "steps": steps,
            "requires_contractor": needs_contractor,
            "feasible": not (set(sim["overallocated_after"]) & involved),
            "portfolio_risk_after_total": sim["portfolio_risk_after_total"],
            "indicative_cost_impact_usd": sim["indicative_cost_impact_usd"],
            "margin_after_pct": sim["margin_after_pct"],
            "affected_programs": [a["program_name"] for a in sim["affected_programs"]],
        })
    results.sort(key=lambda r: (not r["feasible"], r["requires_contractor"],
                                r["portfolio_risk_after_total"], r["indicative_cost_impact_usd"]))
    for i, r in enumerate(results, 1):
        r["rank"] = i
        r["preferred"] = i == 1 and r["feasible"]
    return results
