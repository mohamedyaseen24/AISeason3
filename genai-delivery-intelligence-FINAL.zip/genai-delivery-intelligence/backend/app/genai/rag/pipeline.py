"""RAG pipeline for unstructured business knowledge: parse -> clean -> chunk -> metadata -> embed -> store -> search.
Embeddings are a deterministic hashed n-gram vector (no model download needed). Swap in a real embedding model via
EMBEDDING_MODEL in a later iteration; the storage and search interfaces stay the same.
Retrieved text is treated as untrusted data: chunks matching prompt-injection patterns are quarantined at ingest."""
import hashlib
import os
import re
import zipfile
from xml.etree import ElementTree as ET

import numpy as np

from app.genai.rag.embedder import embed

INJECTION_PATTERNS = [re.compile(p, re.I) for p in [
    r"ignore (all |any |the )?(previous|prior|above) (instructions|prompts?|rules)",
    r"disregard (the )?(previous|above|system|your) ",
    r"you are now\b",
    r"\bsystem prompt\b",
    r"reveal (your|the) (instructions|prompt|api key|secret)",
    r"<\s*/?\s*system\s*>",
    r"\bact as (an? )?(unrestricted|jailbroken|developer mode)",
    r"approve (this|all|every) (change|request|decision)",
]]
ZERO_WIDTH = re.compile(r"[\u200b-\u200f\ufeff\u202a-\u202e]")
CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
METADATA_FIELDS = ("title", "doc_type", "scope", "category", "status", "effective_date", "version")


def read_document(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".md", ".txt"):
        with open(path, encoding="utf-8", errors="replace") as fh:
            return fh.read()
    if ext == ".pdf":
        from pypdf import PdfReader
        return "\n".join((page.extract_text() or "") for page in PdfReader(path).pages)
    if ext == ".docx":
        with zipfile.ZipFile(path) as z:
            root = ET.fromstring(z.read("word/document.xml"))
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paras = []
        for p in root.iter("{%s}p" % ns["w"]):
            paras.append("".join(t.text or "" for t in p.iter("{%s}t" % ns["w"])))
        return "\n".join(paras)
    raise ValueError(f"unsupported file type: {ext}")


def clean(text):
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = ZERO_WIDTH.sub("", CONTROL.sub("", text))
    text = re.sub(r"[ \t]+\n", "\n", text)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def split_front_matter(text):
    meta = {}
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            for line in text[4:end].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip()
            text = text[end + 4:].lstrip("\n")
    return meta, text


def chunk(body, max_chars=700):
    """Split on markdown headings, then on paragraphs. Returns [(section, text)]."""
    sections, current_title, buf = [], "Introduction", []
    for line in body.splitlines():
        if re.match(r"^#{1,3}\s", line):
            if buf:
                sections.append((current_title, "\n".join(buf).strip()))
            current_title, buf = line.lstrip("#").strip(), []
        else:
            buf.append(line)
    if buf:
        sections.append((current_title, "\n".join(buf).strip()))
    out = []
    for title, text in sections:
        if not text:
            continue
        pieces, cur = [], ""
        for para in re.split(r"\n\s*\n", text):
            if len(cur) + len(para) > max_chars and cur:
                pieces.append(cur.strip())
                cur = ""
            cur += para + "\n\n"
        if cur.strip():
            pieces.append(cur.strip())
        out += [(title, p) for p in pieces]
    return out


def is_injection(text):
    return any(p.search(text) for p in INJECTION_PATTERNS)


def ingest_directory(conn, folder):
    summary = {"documents": 0, "chunks": 0, "quarantined": 0, "files": []}
    conn.execute("DELETE FROM kb_chunks")
    conn.execute("DELETE FROM kb_documents")
    for name in sorted(os.listdir(folder)):
        path = os.path.join(folder, name)
        if not os.path.isfile(path) or os.path.splitext(name)[1].lower() not in (".md", ".txt", ".pdf", ".docx"):
            continue
        raw = read_document(path)
        meta, body = split_front_matter(clean(raw))
        # Blockquote lines are notices (e.g. the placeholder banner), not policy text. Keep them out of the index.
        body = "\n".join(line for line in body.splitlines() if not line.lstrip().startswith(">"))
        doc_id = "POL-" + hashlib.sha1(name.encode()).hexdigest()[:6].upper()
        sha = hashlib.sha256(raw.encode("utf-8", errors="replace")).hexdigest()
        conn.execute("INSERT INTO kb_documents VALUES (?,?,?,?,?,?,?,?,?,?)",
                     (doc_id, name, meta.get("title", name), meta.get("doc_type", "POLICY"),
                      meta.get("scope", "ALL"), meta.get("category", "GENERAL"), meta.get("status", "UNSPECIFIED"),
                      meta.get("effective_date", ""), meta.get("version", ""), sha))
        summary["documents"] += 1
        summary["files"].append(name)
        for i, (section, text) in enumerate(chunk(body)):
            quarantined = 1 if is_injection(text) else 0
            summary["quarantined"] += quarantined
            vec = embed(text).astype(np.float32)
            conn.execute("INSERT INTO kb_chunks VALUES (?,?,?,?,?,?)",
                         (f"{doc_id}-C{i + 1:02d}", doc_id, section, text, quarantined, vec.tobytes()))
            summary["chunks"] += 1
    conn.commit()
    return summary


def wrap_untrusted(text):
    return f"<untrusted_policy_excerpt>\n{text}\n</untrusted_policy_excerpt>"


def search(conn, query, k=3, filters=None, min_score=0.15):
    """Semantic search over non-quarantined chunks. Filters are exact matches on document metadata."""
    qvec = embed(query)
    if not np.any(qvec):
        return []
    rows = conn.execute(
        "SELECT c.chunk_id, c.section, c.text, c.embedding, d.doc_id, d.title, d.doc_type, d.scope, d.category, "
        "d.status, d.effective_date, d.version FROM kb_chunks c JOIN kb_documents d ON d.doc_id = c.doc_id "
        "WHERE c.quarantined = 0").fetchall()
    hits = []
    for r in rows:
        meta = {f: r[f] for f in ("doc_type", "scope", "category", "status")}
        if filters and any(meta.get(f) != v for f, v in filters.items()):
            continue
        vec = np.frombuffer(r["embedding"], dtype=np.float32)
        score = float(np.dot(qvec, vec))
        if score >= min_score:
            hits.append({"chunk_id": r["chunk_id"], "doc_id": r["doc_id"], "title": r["title"],
                         "section": r["section"], "doc_type": r["doc_type"], "scope": r["scope"],
                         "category": r["category"], "status": r["status"],
                         "effective_date": r["effective_date"], "version": r["version"],
                         "score": round(score, 3), "text": r["text"]})
    return sorted(hits, key=lambda h: -h["score"])[:k]
