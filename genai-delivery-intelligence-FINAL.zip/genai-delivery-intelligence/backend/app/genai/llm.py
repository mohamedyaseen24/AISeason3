"""Configurable LLM adapter using only the standard library (urllib).
Deterministic mode is used whenever no provider or key is configured. Keys are read from the environment only."""
import json
import urllib.error
import urllib.request

from app import config


class LLMError(Exception):
    pass


class LLMProvider:
    name = "base"

    def complete(self, system, user, max_tokens=900):
        raise NotImplementedError


def _post_json(url, headers, body, timeout):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise LLMError(f"LLM request failed: {type(exc).__name__}") from exc


class OpenAICompatibleProvider(LLMProvider):
    name = "openai_compatible"

    def __init__(self, base_url, api_key, model, timeout=30):
        self.base_url, self.api_key, self.model, self.timeout = base_url.rstrip("/"), api_key, model, timeout

    def complete(self, system, user, max_tokens=900):
        data = _post_json(
            f"{self.base_url}/chat/completions",
            {"Content-Type": "application/json", "Authorization": f"Bearer {self.api_key}"},
            {"model": self.model, "temperature": 0, "max_tokens": max_tokens,
             "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
            self.timeout)
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise LLMError("unexpected response shape") from exc


class AnthropicProvider(LLMProvider):
    name = "anthropic"

    def __init__(self, base_url, api_key, model, timeout=30):
        self.base_url, self.api_key, self.model, self.timeout = base_url.rstrip("/"), api_key, model, timeout

    def complete(self, system, user, max_tokens=900):
        data = _post_json(
            f"{self.base_url}/v1/messages",
            {"Content-Type": "application/json", "x-api-key": self.api_key, "anthropic-version": "2023-06-01"},
            {"model": self.model, "max_tokens": max_tokens, "temperature": 0, "system": system,
             "messages": [{"role": "user", "content": user}]},
            self.timeout)
        try:
            return "".join(block.get("text", "") for block in data["content"] if block.get("type") == "text")
        except (KeyError, TypeError) as exc:
            raise LLMError("unexpected response shape") from exc


class ScriptedProvider(LLMProvider):
    """Test double: returns queued responses. Never used in production paths."""
    name = "scripted"

    def __init__(self, responses):
        self.responses = list(responses)

    def complete(self, system, user, max_tokens=900):
        if not self.responses:
            raise LLMError("no scripted response left")
        return self.responses.pop(0)


def get_provider():
    """Return a configured provider, or None for deterministic mode."""
    if not config.LLM_PROVIDER or not config.LLM_API_KEY or not config.LLM_MODEL:
        return None
    base = config.LLM_BASE_URL or ("https://api.anthropic.com" if config.LLM_PROVIDER == "anthropic" else "")
    if config.LLM_PROVIDER == "anthropic":
        return AnthropicProvider(base, config.LLM_API_KEY, config.LLM_MODEL, config.LLM_TIMEOUT_SECONDS)
    if config.LLM_PROVIDER == "openai_compatible" and base:
        return OpenAICompatibleProvider(base, config.LLM_API_KEY, config.LLM_MODEL, config.LLM_TIMEOUT_SECONDS)
    return None


def llm_status():
    provider = get_provider()
    if provider:
        return {"mode": "llm_validated", "provider": provider.name}
    if config.LLM_PROVIDER:
        return {"mode": "deterministic", "provider": None,
                "reason": "LLM_PROVIDER is set but LLM_API_KEY, LLM_MODEL or LLM_BASE_URL is missing or unsupported."}
    return {"mode": "deterministic", "provider": None, "reason": "No LLM provider configured."}
