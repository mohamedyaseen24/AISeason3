"""Stateful workflow graph with a human-approval checkpoint. Stdlib implementation of the LangGraph pattern
(nodes, edges, conditional routing, persisted state). Swap for LangGraph when it can be installed.
The graph ends at approval: it creates PENDING approval records and never applies a change."""
import json
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from app import approvals
from app.genai import agents
from app.genai.tools import ToolRegistry

END = "__end__"
AGENT_ORDER = ["risk", "dependency", "resource", "scope"]
ROUTE_KEYWORDS = {"risk": ("risk", "delay", "slip", "delivery"), "dependency": ("depend", "overdue", "blocker"),
                  "resource": ("specialist", "resource", "capacity", "move", "allocat"),
                  "scope": ("scope", "change", "request")}
AGENT_FUNCS = {"risk": agents.risk_agent, "dependency": agents.dependency_agent,
               "resource": agents.resource_agent, "scope": agents.scope_agent}


@dataclass
class RunState:
    question: str
    run_id: str = field(default_factory=lambda: "RUN-" + uuid.uuid4().hex[:10])
    route: list = field(default_factory=list)
    findings: list = field(default_factory=list)
    dropped: list = field(default_factory=list)
    approval_ids: list = field(default_factory=list)
    tool_trace: list = field(default_factory=list)
    status: str = "RUNNING"


class StateGraph:
    def __init__(self):
        self.nodes, self.edges, self.conditions, self.entry = {}, {}, {}, None

    def add_node(self, name, fn):
        self.nodes[name] = fn

    def add_edge(self, src, dst):
        self.edges[src] = dst

    def add_conditional(self, src, fn):
        self.conditions[src] = fn

    def run(self, state, max_steps=50):
        current = self.entry
        for _ in range(max_steps):
            if current == END:
                return state
            state = self.nodes[current](state)
            current = self.conditions[current](state) if current in self.conditions else self.edges.get(current, END)
        raise RuntimeError("graph exceeded max steps")


def _route(state):
    q = state.question.lower()
    picked = [a for a, words in ROUTE_KEYWORDS.items() if any(w in q for w in words)]
    state.route = picked or list(AGENT_ORDER)
    return state


def _make_agent_node(name):
    def node(state, reg=None):
        if name in state.route:
            state.findings += AGENT_FUNCS[name](reg, state)
        return state
    return node


def _validate(state):
    good = []
    for f in state.findings:
        problems = []
        if not f.get("evidence"):
            problems.append("no evidence")
        if not f.get("tool_calls"):
            problems.append("no tool call trace")
        if f.get("approval_required") is not True:
            problems.append("approval flag missing")
        if problems:
            state.dropped.append({"entity": f.get("entity"), "problems": problems})
        else:
            good.append(f)
    state.findings = good
    return state


def build_graph(reg):
    g = StateGraph()
    g.entry = "route"
    g.add_node("route", _route)
    for name in AGENT_ORDER:
        g.add_node(name, lambda st, n=name: _make_agent_node(n)(st, reg))
    g.add_node("portfolio", lambda st: _portfolio(st, reg))
    g.add_node("validate", _validate)
    g.add_node("approval", lambda st: _approval(st, reg.conn))
    chain = AGENT_ORDER + ["portfolio", "validate"]
    g.add_edge("route", chain[0])
    for a, b in zip(chain, chain[1:]):
        g.add_edge(a, b)
    g.add_conditional("validate", lambda st: "approval" if st.findings else END)
    g.add_edge("approval", END)
    return g


def _portfolio(state, reg):
    if reg.snap["programs"]:
        state.findings += agents.portfolio_agent(reg, state)
    return state


def _approval(state, conn):
    existing = {(r["kind"], r["entity"], r["summary"]): r["id"] for r in approvals.list_items(conn, "PENDING")}
    for f in state.findings:
        key = (f["type"], f["entity"], f["summary"])
        if key in existing:
            state.approval_ids.append(existing[key])
            continue
        state.approval_ids.append(approvals.create(conn, f["type"], f["entity"], f, f["summary"],
                                                   f["source"], approvals.AI_ACTOR))
    state.status = "AWAITING_HUMAN_APPROVAL"
    return state


def run_pipeline(snap, conn, question, created_by):
    """Run the full agent workflow. Returns the final state and persists it in agent_runs."""
    reg = ToolRegistry(snap, conn)
    state = RunState(question=question)
    graph = build_graph(reg)
    graph.entry = "route"
    state = graph.run(state)
    if state.status == "RUNNING":
        state.status = "COMPLETED_NO_FINDINGS"
    state.tool_trace = reg.trace
    conn.execute("INSERT INTO agent_runs VALUES (?,?,?,?,?,?)",
                 (state.run_id, question, state.status, json.dumps(asdict(state), default=str), created_by,
                  datetime.now(timezone.utc).isoformat()))
    conn.commit()
    return asdict(state)
