"""FICTIONAL synthetic portfolio. Not real business records.

ORIGINAL_BASELINE holds the supplied business inputs and must not change.
Everything else is a SYNTHETIC example record built to reconcile to those inputs.
"""

DISCLAIMER = "SYNTHETIC EXAMPLE DATA - fictional customers, programs, people and dependencies."

ORIGINAL_BASELINE = {  # ORIGINAL BUSINESS INPUTS
    "portfolio_size_programs": 5,
    "enterprise_customers": 3,
    "milestones_on_time_pct": 71,
    "open_dependencies": 17,
    "overdue_dependencies": 6,
    "overallocated_key_specialist_roles": 2,
    "current_specialist_allocation_pct": 125,
    "pending_change_requests": 14,
    "actual_portfolio_margin_pct": 17,
    "planned_portfolio_margin_pct": 22,
}

# (customer_id, name, sector)
CUSTOMERS = [
    ("C-01", "Northwind Retail", "Retail"),
    ("C-02", "Bluewater Health", "Healthcare"),
    ("C-03", "Summit Logistics", "Logistics"),
]

# (program_id, customer_id, name, type, revenue_usd, cost_usd)  totals: revenue 12.0M, cost 9.96M => 17.0%
PROGRAMS = [
    ("PRG-001", "C-01", "Digital Business Launch", "Digital launch", 3000000, 2490000),
    ("PRG-002", "C-02", "Core Systems Modernization", "Modernization", 2400000, 2016000),
    ("PRG-003", "C-01", "Seasonal Support Program", "Seasonal support", 1800000, 1476000),
    ("PRG-004", "C-03", "Enterprise App Development", "Application development", 3000000, 2490000),
    ("PRG-005", "C-03", "Application Support and Transformation", "Support and transformation", 1800000, 1488000),
]

# (milestone_id, program_id, name, planned, forecast, status)
# status: ON_TIME (delivered or on plan) | LATE | AT_RISK. 17 ON_TIME of 24 => 70.8% (reported as 71%)
MILESTONES = [
    ("M-001", "PRG-001", "Discovery sign-off", "2026-03-31", "2026-03-31", "ON_TIME"),
    ("M-002", "PRG-001", "Commerce MVP build complete", "2026-06-30", "2026-06-30", "ON_TIME"),
    ("M-003", "PRG-001", "Payment gateway integration", "2026-09-30", "2026-10-30", "AT_RISK"),
    ("M-004", "PRG-001", "Pilot launch", "2026-10-15", "2026-12-14", "LATE"),
    ("M-005", "PRG-001", "Digital launch go-live", "2026-12-15", "2026-12-15", "ON_TIME"),
    ("M-006", "PRG-002", "Legacy data extraction", "2026-04-30", "2026-04-30", "ON_TIME"),
    ("M-007", "PRG-002", "Identity integration", "2026-07-31", "2026-07-31", "ON_TIME"),
    ("M-008", "PRG-002", "Core API build", "2026-09-30", "2026-09-30", "ON_TIME"),
    ("M-009", "PRG-002", "Reporting migration", "2026-10-15", "2026-11-30", "LATE"),
    ("M-010", "PRG-002", "Cutover readiness", "2026-12-20", "2026-12-20", "ON_TIME"),
    ("M-011", "PRG-003", "Support process design", "2026-05-31", "2026-05-31", "ON_TIME"),
    ("M-012", "PRG-003", "Weekend coverage model", "2026-08-31", "2026-08-31", "ON_TIME"),
    ("M-013", "PRG-003", "Peak-season load test", "2026-10-31", "2026-10-31", "ON_TIME"),
    ("M-014", "PRG-003", "Promotions rules integration", "2026-11-20", "2026-12-05", "AT_RISK"),
    ("M-015", "PRG-003", "Peak-season go-live", "2026-12-01", "2026-12-01", "ON_TIME"),
    ("M-016", "PRG-004", "Architecture baseline", "2026-02-28", "2026-02-28", "ON_TIME"),
    ("M-017", "PRG-004", "Partner API integration", "2026-06-30", "2026-06-30", "ON_TIME"),
    ("M-018", "PRG-004", "Offline sync module", "2026-09-15", "2026-11-30", "LATE"),
    ("M-019", "PRG-004", "Shipment tracking MVP", "2026-11-30", "2026-11-30", "ON_TIME"),
    ("M-020", "PRG-004", "Legacy logistics feed", "2026-12-10", "2026-12-20", "AT_RISK"),
    ("M-021", "PRG-005", "Operations runbook approval", "2026-03-31", "2026-03-31", "ON_TIME"),
    ("M-022", "PRG-005", "Incident process rollout", "2026-07-31", "2026-07-31", "ON_TIME"),
    ("M-023", "PRG-005", "Transformation wave 1", "2026-10-31", "2026-10-31", "ON_TIME"),
    ("M-024", "PRG-005", "Test data masking complete", "2026-10-15", "2026-11-20", "LATE"),
]

# (dependency_id, provider_program, dependent_program, description, owner, due_date, downstream_milestone, status)
# Exactly 17 OPEN; exactly 6 have due dates before the as-of date 2026-11-05.
DEPENDENCIES = [
    ("DEP-01", "PRG-002", "PRG-001", "Customer identity API contract sign-off", "R. Sato (Bluewater IT)", "2026-10-09", "M-003", "OPEN"),
    ("DEP-02", "PRG-004", "PRG-001", "Order service data model sign-off", "Lena Fischer", "2026-10-16", "M-003", "OPEN"),
    ("DEP-03", "PRG-003", "PRG-001", "Peak-season test environment provisioning", "Priya Nair", "2026-09-28", "M-004", "OPEN"),
    ("DEP-04", "PRG-005", "PRG-004", "Legacy logistics feed access approval", "Hannah Lee", "2026-10-23", "M-020", "OPEN"),
    ("DEP-05", "PRG-002", "PRG-005", "Test data masking approval", "Diego Alvarez", "2026-10-30", "M-024", "OPEN"),
    ("DEP-06", "PRG-001", "PRG-003", "Promotions rules engine release", "Elena Park", "2026-10-02", "M-014", "OPEN"),
    ("DEP-07", "PRG-004", "PRG-002", "Partner API version confirmation", "Lena Fischer", "2026-11-12", "M-009", "OPEN"),
    ("DEP-08", "PRG-002", "PRG-004", "Offline sync data schema", "Tom Okafor", "2026-11-19", "M-018", "OPEN"),
    ("DEP-09", "PRG-003", "PRG-005", "Operations calendar alignment", "Sam Ortiz", "2026-11-20", "M-023", "OPEN"),
    ("DEP-10", "PRG-001", "PRG-002", "Product catalogue feed", "Elena Park", "2026-11-26", "M-009", "OPEN"),
    ("DEP-11", "PRG-005", "PRG-003", "Support ticket taxonomy", "Hannah Lee", "2026-12-03", "M-013", "OPEN"),
    ("DEP-12", "PRG-004", "PRG-001", "Checkout API performance sign-off", "Marcus Bell", "2026-12-08", "M-005", "OPEN"),
    ("DEP-13", "PRG-002", "PRG-003", "Customer data export for peak testing", "Tom Okafor", "2026-12-10", "M-015", "OPEN"),
    ("DEP-14", "PRG-001", "PRG-004", "Shipping rate table", "Mia Chen", "2026-12-15", "M-019", "OPEN"),
    ("DEP-15", "PRG-003", "PRG-001", "Loyalty support runbook", "Mia Chen", "2026-12-18", "M-005", "OPEN"),
    ("DEP-16", "PRG-005", "PRG-002", "Legacy reporting access", "Hannah Lee", "2027-01-08", "M-010", "OPEN"),
    ("DEP-17", "PRG-004", "PRG-005", "Transformation wave API handover", "Lena Fischer", "2027-01-15", "M-023", "OPEN"),
]

# (specialist_id, name, role, is_key_role)
SPECIALISTS = [
    ("SP-01", "Elena Park", "Solution Architect", 0),
    ("SP-02", "Marcus Bell", "Solution Architect", 1),
    ("SP-03", "Priya Nair", "Test Lead", 1),
    ("SP-04", "Tom Okafor", "Senior Engineer", 0),
    ("SP-05", "Lena Fischer", "Senior Engineer", 0),
    ("SP-06", "Sam Ortiz", "QA Engineer", 0),
    ("SP-07", "Ravi Kumar", "Integration Specialist", 0),
    ("SP-08", "Hannah Lee", "Support Engineer", 0),
    ("SP-09", "Diego Alvarez", "Data Engineer", 0),
    ("SP-10", "Mia Chen", "Business Analyst", 0),
]

# (specialist_id, program_id, allocation_pct). Totals: SP-02 and SP-03 = 125%.
ALLOCATIONS = [
    ("SP-01", "PRG-001", 50), ("SP-01", "PRG-002", 25),
    ("SP-02", "PRG-001", 60), ("SP-02", "PRG-004", 65),
    ("SP-03", "PRG-002", 70), ("SP-03", "PRG-003", 55),
    ("SP-04", "PRG-002", 100),
    ("SP-05", "PRG-004", 100),
    ("SP-06", "PRG-003", 50), ("SP-06", "PRG-005", 40),
    ("SP-07", "PRG-001", 40), ("SP-07", "PRG-004", 30),
    ("SP-08", "PRG-005", 100),
    ("SP-09", "PRG-002", 30), ("SP-09", "PRG-005", 30),
    ("SP-10", "PRG-003", 40), ("SP-10", "PRG-001", 30),
]

# (change_id, program_id, title, effort_days, schedule_impact_days, skills, dependency_impact, commitment_conflict, status)
CHANGE_REQUESTS = [
    ("CR-01", "PRG-001", "Add loyalty points redemption at checkout", 40, 12, "Solution Architect; Engineer", True, True, "PENDING"),
    ("CR-02", "PRG-001", "Add multi-currency pricing", 25, 8, "Solution Architect; Integration Specialist", True, True, "PENDING"),
    ("CR-03", "PRG-001", "Add extra analytics dashboard", 10, 3, "Business Analyst", False, False, "PENDING"),
    ("CR-04", "PRG-002", "Migrate 12 additional legacy reports", 30, 15, "Data Engineer; Senior Engineer", False, False, "PENDING"),
    ("CR-05", "PRG-002", "Add audit log export", 8, 2, "Senior Engineer", False, False, "PENDING"),
    ("CR-06", "PRG-002", "Upgrade authentication library", 18, 6, "Senior Engineer; Test Lead", True, False, "PENDING"),
    ("CR-07", "PRG-003", "Add weekend on-call coverage", 20, 0, "Support Engineer", False, True, "PENDING"),
    ("CR-08", "PRG-003", "Add extra peak-season load test cycles", 12, 5, "Test Lead; QA Engineer", True, False, "PENDING"),
    ("CR-09", "PRG-004", "Add offline sync module for mobile app", 35, 14, "Solution Architect; Senior Engineer", True, True, "PENDING"),
    ("CR-10", "PRG-004", "Change partner API version", 15, 4, "Integration Specialist", False, False, "PENDING"),
    ("CR-11", "PRG-005", "Add operations incident dashboards", 9, 2, "Business Analyst", False, False, "PENDING"),
    ("CR-12", "PRG-005", "Extend support hours to 20:00", 14, 0, "Support Engineer", False, True, "PENDING"),
    ("CR-13", "PRG-001", "Accessibility (WCAG) audit fixes", 16, 5, "QA Engineer", False, False, "PENDING"),
    ("CR-14", "PRG-004", "Add real-time shipment tracking widget", 22, 9, "Senior Engineer; Integration Specialist", True, False, "PENDING"),
]
