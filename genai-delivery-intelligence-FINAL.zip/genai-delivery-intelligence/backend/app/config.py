"""Environment-driven configuration. No secrets or model names are hardcoded."""
import os
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

AS_OF_DATE = date.fromisoformat(os.getenv("AS_OF_DATE", "2026-11-05"))
DATABASE_PATH = os.getenv("DATABASE_PATH", str(ROOT / "data" / "portfolio.db"))
REPORTS_DIR = os.getenv("REPORTS_DIR", str(ROOT / "reports"))
KNOWLEDGE_BASE_DIR = os.getenv("KNOWLEDGE_BASE_DIR", str(ROOT / "knowledge_base" / "policies"))
FRONTEND_DIST = os.getenv("FRONTEND_DIST", str(ROOT / "frontend" / "dist"))
SERVER_HOST = os.getenv("SERVER_HOST", "127.0.0.1")
SERVER_PORT = int(os.getenv("SERVER_PORT", "8000"))

# Optional LLM. Empty LLM_PROVIDER means deterministic mode. Keys come only from the environment.
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "")          # "openai_compatible" | "anthropic" | ""
LLM_MODEL = os.getenv("LLM_MODEL", "")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "")          # e.g. https://api.openai.com/v1 or https://api.anthropic.com
LLM_TIMEOUT_SECONDS = int(os.getenv("LLM_TIMEOUT_SECONDS", "30"))

PLANNED_MARGIN_PCT = 22.0
BLENDED_RATE_USD_PER_DAY = 850
CONTRACTOR_RATE_USD_PER_DAY = 1100
CAPACITY_PER_SPECIALIST_PCT = 100
CAPACITY_WARN_PCT = 90

# Transparent risk scoring weights (max 100 points per program)
W_MILESTONE_SLIP = 30       # share of milestones not ON_TIME
W_OVERDUE_DEP_EACH = 8      # per overdue open dependency touching the program
W_OVERDUE_DEP_CAP = 25
W_CAPACITY_OVER = 25        # a specialist on the program is above 100%
W_CAPACITY_WARN = 10        # a specialist on the program is at or above CAPACITY_WARN_PCT
W_SCOPE = 20                # pending/simulated schedule impact
SCOPE_SATURATION_DAYS = 15
RISK_HIGH_THRESHOLD = 60
RISK_MEDIUM_THRESHOLD = 35

ESCALATE_P1_DAYS = 30
ESCALATE_P2_DAYS = 14

# Recovery TARGETS. Proposals only, never achieved results.
TARGET_ON_TIME_DAY90_PCT = 80.0
TARGET_MARGIN_DAY90_PCT = 20.0
