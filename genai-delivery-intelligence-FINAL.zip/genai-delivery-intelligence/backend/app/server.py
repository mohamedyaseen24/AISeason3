"""JSON API and static host, standard library only (replaces the FastAPI draft, which could not be installed).
Security: token auth with hashed sessions, role permissions on every route, JSON size limit, input validation,
rate limits on login and AI calls, strict security headers, and path-traversal protection for static files."""
import json
import mimetypes
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

from app import approvals, config, security
from app.database import connect, log_audit
from app.genai import decision_assistant, llm, orchestrator
from app.genai.rag import pipeline as rag
from app.services import dependency_service, portfolio_service, report_service, resource_service
from app.services import risk_service, scope_service, sensitivity, simulation_service
from app.services.snapshot import load_snapshot

MAX_BODY = 64 * 1024
MAX_COMPOSITE_STEPS = 10
ASK_LIMIT = security.TokenBucket(capacity=10, refill_per_sec=10 / 60)
LOGIN_LIMIT = security.TokenBucket(capacity=5, refill_per_sec=5 / 300)
USERNAME_RE = re.compile(r"^[a-z0-9._-]{3,40}$")
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:",
}


class HTTPError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status, self.message = status, message


class Raw:
    def __init__(self, body, content_type, filename=None):
        self.body, self.content_type, self.filename = body, content_type, filename


class Ctx:
    def __init__(self, conn, user, params, query, body, client):
        self.conn, self.user, self.params, self.query, self.body, self.client = conn, user, params, query, body, client


def _snap():
    return load_snapshot()


def _filter_rows(rows, query, mapping):
    for key, field in mapping.items():
        if query.get(key):
            wanted = query[key]
            rows = [r for r in rows if str(r.get(field, "")).upper() == wanted.upper()]
    return rows


# ---------- handlers ----------
def h_health(c):
    return {"status": "ok", "llm": llm.llm_status()}


def h_me(c):
    return {"username": c.user["username"], "role": c.user["role"],
            "permissions": sorted(security.ROLE_PERMISSIONS[c.user["role"]])}


def h_overview(c):
    return portfolio_service.overview(_snap())


def h_reconcile(c):
    return portfolio_service.reconcile(_snap())


def h_programs(c):
    return portfolio_service.program_status(_snap())


def h_customers(c):
    return portfolio_service.customer_performance(_snap())


def h_risks(c):
    return risk_service.all_program_risks(_snap())


def h_dependencies(c):
    rows = dependency_service.dependency_register(_snap())
    if c.query.get("program"):
        p = c.query["program"].upper()
        rows = [r for r in rows if p in (r["provider_program_id"], r["dependent_program_id"])]
    if c.query.get("priority"):
        rows = _filter_rows(rows, c.query, {"priority": "escalation_priority"})
    if c.query.get("due_before"):
        try:
            from datetime import date
            cutoff = date.fromisoformat(c.query["due_before"]).isoformat()
        except ValueError:
            raise HTTPError(400, "due_before must be YYYY-MM-DD")
        rows = [r for r in rows if r["due_date"] <= cutoff]
    return rows


def h_specialists(c):
    return resource_service.specialist_loads(_snap())


def h_changes(c):
    rows = scope_service.assess(_snap())
    return _filter_rows(rows, c.query, {"impact": "impact", "recommendation": "recommendation",
                                        "program": "program_id"})


def h_reallocation(c):
    return simulation_service.reallocation_options(_snap(), c.params["sid"])


def h_sensitivity(c):
    return sensitivity.run(_snap())


def h_approvals(c):
    status = c.query.get("status")
    if status and status not in approvals.DECISIONS | {"PENDING"}:
        raise HTTPError(400, "status must be PENDING, APPROVED or REJECTED")
    return approvals.list_items(c.conn, status.upper() if status else None)


def h_decide(c):
    body = c.body
    comment = body.get("comment", "")
    if not isinstance(comment, str):
        raise HTTPError(400, "comment must be a string")
    return approvals.decide(c.conn, c.user, int(c.params["id"]), str(body.get("decision", "")), comment)


def h_policies(c):
    if c.query.get("q"):
        q = security.validate_question(c.query["q"])
        return rag.search(c.conn, q, k=5, min_score=0.15)
    return [dict(r) for r in c.conn.execute("SELECT doc_id, title, doc_type, scope, category, status, version, "
                                            "effective_date FROM kb_documents ORDER BY doc_id").fetchall()]


def h_policy_ingest(c):
    return rag.ingest_directory(c.conn, config.KNOWLEDGE_BASE_DIR)


def h_ask(c):
    if not ASK_LIMIT.allow(c.user["username"]):
        raise HTTPError(429, "too many questions; wait a minute and retry")
    question = security.validate_question(c.body.get("question"))
    log_audit(c.conn, c.user["username"], "AI_QUERY", "assistant", question[:200])
    c.conn.commit()
    return decision_assistant.answer(_snap(), question, conn=c.conn, provider=llm.get_provider())


def _check_scenario(scenario):
    if not isinstance(scenario, dict) or scenario.get("type") not in simulation_service.SUPPORTED_TYPES:
        raise HTTPError(400, "scenario.type is not supported")
    if scenario["type"] == "COMPOSITE":
        steps = scenario.get("steps")
        if not isinstance(steps, list) or not 1 <= len(steps) <= MAX_COMPOSITE_STEPS:
            raise HTTPError(400, f"composite scenarios need 1 to {MAX_COMPOSITE_STEPS} steps")
        for s in steps:
            _check_scenario(s)
    elif not isinstance(scenario.get("params", {}), dict):
        raise HTTPError(400, "scenario.params must be an object")
    for key, value in scenario.get("params", {}).items():
        if isinstance(value, (int, float)) and not isinstance(value, bool) and not 0 <= value <= 1000:
            raise HTTPError(400, f"parameter {key} out of range")


def h_simulate(c):
    scenario = c.body.get("scenario")
    _check_scenario(scenario)
    return simulation_service.simulate(_snap(), scenario)


def h_agent_run(c):
    question = security.validate_question(c.body.get("question"))
    if not ASK_LIMIT.allow("run:" + c.user["username"]):
        raise HTTPError(429, "too many agent runs; wait a minute and retry")
    run = orchestrator.run_pipeline(_snap(), c.conn, question, c.user["username"])
    return {"run_id": run["run_id"], "status": run["status"], "route": run["route"],
            "findings": run["findings"], "approval_ids": run["approval_ids"], "dropped": run["dropped"],
            "note": "Findings are recommendations. Each one waits in the approval queue."}


def h_agent_runs(c):
    rows = c.conn.execute("SELECT run_id, question, status, created_by, created_at FROM agent_runs "
                          "ORDER BY created_at DESC LIMIT 50").fetchall()
    return [dict(r) for r in rows]


def h_reports_build(c):
    paths = report_service.build_all(_snap())
    return {"files": [os.path.basename(p) for p in paths.values()]}


def h_report_download(c):
    name = c.params["name"]
    if not re.fullmatch(r"[A-Za-z0-9_.-]+\.(pdf|xlsx)", name):
        raise HTTPError(400, "invalid file name")
    path = os.path.join(config.REPORTS_DIR, name)
    if not os.path.isfile(path):
        raise HTTPError(404, "report not found; build reports first")
    ctype = "application/pdf" if name.endswith(".pdf") else \
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    with open(path, "rb") as fh:
        return Raw(fh.read(), ctype, name)


def h_logout(c):
    token = c.params.get("token")
    security.revoke_session(c.conn, token)
    return {"status": "logged out"}


def h_login(c):
    username = str(c.body.get("username", ""))[:80]
    password = str(c.body.get("password", ""))[:200]
    key = f"{c.client}:{username}"
    if not LOGIN_LIMIT.allow(key):
        raise HTTPError(429, "too many login attempts; wait and retry")
    user = security.authenticate(c.conn, username, password)
    if user is None:
        log_audit(c.conn, username or "unknown", "LOGIN_FAILED", "auth", c.client)
        c.conn.commit()
        raise HTTPError(401, "invalid username or password")
    token = security.create_session(c.conn, user["user_id"])
    log_audit(c.conn, user["username"], "LOGIN", "auth", c.client)
    c.conn.commit()
    return {"token": token, "username": user["username"], "role": user["role"]}


def h_users_list(c):
    return [dict(r) for r in c.conn.execute(
        "SELECT user_id, username, display_name, role, active FROM users ORDER BY username").fetchall()]


def h_user_create(c):
    username = str(c.body.get("username", ""))
    if not USERNAME_RE.match(username):
        raise HTTPError(400, "username must be 3-40 characters: lowercase letters, digits, . _ -")
    role = str(c.body.get("role", ""))
    if role not in security.ROLE_PERMISSIONS:
        raise HTTPError(400, "role must be VIEWER, ANALYST, APPROVER or ADMIN")
    password = c.body.get("password")
    security.validate_password(password)
    try:
        c.conn.execute("INSERT INTO users(user_id, username, display_name, password_hash, role, active) "
                       "VALUES (?,?,?,?,?,1)", (f"U-{username}", username,
                                                str(c.body.get("display_name", username))[:80],
                                                security.hash_password(password), role))
    except Exception:
        raise HTTPError(409, "username already exists")
    log_audit(c.conn, c.user["username"], "USER_CREATED", "users", f"{username} as {role}")
    c.conn.commit()
    return {"username": username, "role": role}


# (method, pattern, required permission or None, handler, needs_auth)
ROUTES = [
    ("GET", r"/api/health", None, h_health),
    ("GET", r"/api/me", "read", h_me),
    ("GET", r"/api/overview", "read", h_overview),
    ("GET", r"/api/reconciliation", "read", h_reconcile),
    ("GET", r"/api/programs", "read", h_programs),
    ("GET", r"/api/customers", "read", h_customers),
    ("GET", r"/api/risks", "read", h_risks),
    ("GET", r"/api/dependencies", "read", h_dependencies),
    ("GET", r"/api/specialists", "read", h_specialists),
    ("GET", r"/api/change-requests", "read", h_changes),
    ("GET", r"/api/reallocation/(?P<sid>SP-\d{2})", "read", h_reallocation),
    ("GET", r"/api/sensitivity", "read", h_sensitivity),
    ("GET", r"/api/approvals", "read", h_approvals),
    ("POST", r"/api/approvals/(?P<id>\d+)/decide", "approve", h_decide),
    ("GET", r"/api/policies", "read", h_policies),
    ("POST", r"/api/policies/ingest", "manage_users", h_policy_ingest),
    ("POST", r"/api/ask", "ask", h_ask),
    ("POST", r"/api/simulate", "simulate", h_simulate),
    ("POST", r"/api/agent-runs", "agent_run", h_agent_run),
    ("GET", r"/api/agent-runs", "read", h_agent_runs),
    ("POST", r"/api/reports", "reports", h_reports_build),
    ("GET", r"/api/reports/(?P<name>[^/]+)", "reports", h_report_download),
    ("POST", r"/api/auth/login", None, h_login),
    ("POST", r"/api/auth/logout", "read", h_logout),
    ("GET", r"/api/admin/users", "manage_users", h_users_list),
    ("POST", r"/api/admin/users", "manage_users", h_user_create),
]


class Handler(BaseHTTPRequestHandler):
    server_version = "DeliveryIntel/0.2"

    def log_message(self, fmt, *args):  # keep test and console output quiet
        return

    def _send(self, status, payload, content_type="application/json; charset=utf-8", extra=None):
        body = payload if isinstance(payload, bytes) else json.dumps(payload, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in {**SECURITY_HEADERS, **(extra or {})}.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _static(self, path):
        root = os.path.realpath(config.FRONTEND_DIST)
        rel = "index.html" if path in ("", "/") else path.lstrip("/")
        target = os.path.realpath(os.path.join(root, rel))
        if not target.startswith(root + os.sep) or not os.path.isfile(target):
            target = os.path.join(root, "index.html")
        if not os.path.isfile(target):
            return self._send(404, {"error": "frontend not built; run the frontend build script"})
        ctype = mimetypes.guess_type(target)[0] or "application/octet-stream"
        with open(target, "rb") as fh:
            self._send(200, fh.read(), ctype)

    def _handle(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        if not path.startswith("/api/"):
            if method != "GET":
                return self._send(405, {"error": "method not allowed"})
            return self._static(path)
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}
        conn = connect()
        try:
            body = {}
            if method == "POST":
                length = int(self.headers.get("Content-Length") or 0)
                if length > MAX_BODY:
                    raise HTTPError(413, "request body too large")
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw.decode("utf-8")) if raw else {}
                except (UnicodeDecodeError, json.JSONDecodeError):
                    raise HTTPError(400, "invalid JSON body")
                if not isinstance(body, dict):
                    raise HTTPError(400, "JSON body must be an object")
            for route_method, pattern, perm, fn in ROUTES:
                if route_method != method:
                    continue
                m = re.fullmatch(pattern, path)
                if not m:
                    continue
                token = (self.headers.get("Authorization") or "")[7:].strip() \
                    if (self.headers.get("Authorization") or "").startswith("Bearer ") else None
                user = security.user_for_token(conn, token) if perm is not None or fn is h_logout else None
                if perm is not None and user is None:
                    raise HTTPError(401, "authentication required")
                if perm is not None and not security.has_permission(user, perm):
                    raise HTTPError(403, "your role does not allow this action")
                ctx = Ctx(conn, user, {**m.groupdict(), "token": token}, query, body, self.client_address[0])
                result = fn(ctx)
                if isinstance(result, Raw):
                    return self._send(200, result.body, result.content_type,
                                      {"Content-Disposition": f'attachment; filename="{result.filename}"'})
                return self._send(201 if fn in (h_user_create,) else 200, result)
            raise HTTPError(404, "no such endpoint")
        except HTTPError as e:
            self._send(e.status, {"error": e.message})
        except PermissionError as e:
            self._send(403, {"error": str(e)})
        except KeyError as e:
            self._send(404, {"error": str(e).strip("'")})
        except ValueError as e:
            self._send(400, {"error": str(e)})
        finally:
            conn.close()

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")


def make_server(host=None, port=None):
    return ThreadingHTTPServer((host or config.SERVER_HOST, config.SERVER_PORT if port is None else port), Handler)


def serve_forever():
    server = make_server()
    print(f"Serving on http://{server.server_address[0]}:{server.server_address[1]}")
    server.serve_forever()
