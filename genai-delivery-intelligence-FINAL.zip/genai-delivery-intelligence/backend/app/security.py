"""Authentication, sessions, role-based permissions, input validation and rate limiting."""
import hashlib
import hmac
import re
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone
from functools import lru_cache

ROLE_PERMISSIONS = {
    "VIEWER": {"read"},
    "ANALYST": {"read", "simulate", "ask", "agent_run", "reports"},
    "APPROVER": {"read", "simulate", "ask", "agent_run", "reports", "approve"},
    "ADMIN": {"read", "simulate", "ask", "agent_run", "reports", "approve", "manage_users"},
}
DEMO_USERS = [("viewer.demo", "Demo Viewer", "VIEWER"), ("analyst.demo", "Demo Analyst", "ANALYST"),
              ("leader.demo", "Demo Portfolio Leader", "APPROVER"), ("admin.demo", "Demo Admin", "ADMIN")]
SESSION_TTL_HOURS = 8
PBKDF2_ITERATIONS = 200_000
MIN_PASSWORD_LENGTH = 12
_QUESTION_BAD = re.compile(r"[^\w\s?.,'\"()\-/&%$:;!+#]")
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f\u200b-\u200f\ufeff]")


def _hash_token(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def hash_password(password):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${PBKDF2_ITERATIONS}${salt.hex()}${dk.hex()}"


def verify_password(password, stored):
    try:
        _, iters, salt_hex, hash_hex = stored.split("$")
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters))
        return hmac.compare_digest(dk.hex(), hash_hex)
    except (ValueError, TypeError):
        return False


@lru_cache(maxsize=1)
def _dummy_hash():
    return hash_password("placeholder-password-for-timing")


def authenticate(conn, username, password):
    row = conn.execute("SELECT * FROM users WHERE username = ? AND active = 1", (username,)).fetchone()
    if row is None:
        verify_password(password, _dummy_hash())  # equalise timing for unknown users
        return None
    return dict(row) if verify_password(password, row["password_hash"]) else None


def create_session(conn, user_id):
    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    conn.execute("INSERT INTO sessions(token_hash, user_id, created_at, expires_at) VALUES (?,?,?,?)",
                 (_hash_token(token), user_id, now.isoformat(),
                  (now + timedelta(hours=SESSION_TTL_HOURS)).isoformat()))
    conn.commit()
    return token


def user_for_token(conn, token):
    if not token:
        return None
    row = conn.execute(
        "SELECT u.* FROM sessions s JOIN users u ON u.user_id = s.user_id "
        "WHERE s.token_hash = ? AND u.active = 1 AND s.expires_at > ?",
        (_hash_token(token), datetime.now(timezone.utc).isoformat())).fetchone()
    return dict(row) if row else None


def revoke_session(conn, token):
    conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_hash_token(token),))
    conn.commit()


def has_permission(user, permission):
    return user is not None and permission in ROLE_PERMISSIONS.get(user["role"], set())


def validate_question(text):
    if not isinstance(text, str):
        raise ValueError("question must be a string")
    cleaned = _CONTROL.sub("", text).strip()
    if not 3 <= len(cleaned) <= 500:
        raise ValueError("question must be 3 to 500 characters")
    if _QUESTION_BAD.search(cleaned):
        raise ValueError("question contains unsupported characters")
    return cleaned


def validate_password(password):
    if not isinstance(password, str) or len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"password must be at least {MIN_PASSWORD_LENGTH} characters")


class TokenBucket:
    """Per-key rate limiter (in-memory, single process)."""

    def __init__(self, capacity, refill_per_sec):
        self.capacity = capacity
        self.rate = refill_per_sec
        self.state = {}
        self.lock = threading.Lock()

    def allow(self, key):
        with self.lock:
            now = time.monotonic()
            tokens, last = self.state.get(key, (float(self.capacity), now))
            tokens = min(self.capacity, tokens + (now - last) * self.rate)
            if tokens >= 1:
                self.state[key] = (tokens - 1, now)
                return True
            self.state[key] = (tokens, now)
            return False


def seed_demo_users(conn):
    """Create demo accounts with random passwords. Returns {username: password} for the operator to store."""
    creds = {}
    for username, display, role in DEMO_USERS:
        password = secrets.token_urlsafe(12)
        creds[username] = {"password": password, "role": role}
        conn.execute("INSERT INTO users(user_id, username, display_name, password_hash, role, active) "
                     "VALUES (?,?,?,?,?,1)", (f"U-{username}", username, display, hash_password(password), role))
    conn.commit()
    return creds
