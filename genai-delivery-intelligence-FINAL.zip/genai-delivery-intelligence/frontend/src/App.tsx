import { useEffect, useState } from "react";
import { api, setToken, getToken } from "./api";
import type { Me } from "./types";
import Login from "./views/Login";
import Overview from "./views/Overview";
import Dependencies from "./views/Dependencies";
import Resources from "./views/Resources";
import Approvals from "./views/Approvals";
import Assistant from "./views/Assistant";

type View = "overview" | "dependencies" | "resources" | "approvals" | "assistant";
const VIEWS: [View, string][] = [
  ["overview", "Overview"], ["dependencies", "Dependencies"], ["resources", "Resources & scope"],
  ["approvals", "Approvals"], ["assistant", "Assistant"],
];

export default function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [view, setView] = useState<View>("overview");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!getToken()) {
      setReady(true);
      return;
    }
    api<Me>("/api/me")
      .then(setMe)
      .catch(() => setToken(null))
      .finally(() => setReady(true));
  }, []);

  if (!ready) return <p className="pad">Loading...</p>;
  if (!me) return <Login onLogin={setMe} />;

  const can = (perm: string) => me.permissions.includes(perm);
  const logout = () => {
    api("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setToken(null);
    setMe(null);
  };

  return (
    <>
      <header>
        <h1>Delivery Intelligence</h1>
        <nav>
          {VIEWS.map(([id, label]) => (
            <button key={id} className={view === id ? "active" : ""} onClick={() => setView(id)}>{label}</button>
          ))}
        </nav>
        <span className="muted" style={{ marginLeft: "auto" }}>{me.username} ({me.role})</span>
        <button className="secondary" onClick={logout}>Sign out</button>
      </header>
      <main>
        <div className="banner">
          Synthetic example data: fictional customers, programs, people and dependencies. Figures marked
          ORIGINAL INPUT are the supplied business values. AI output is a recommendation awaiting human approval.
        </div>
        {view === "overview" && <Overview can={can} />}
        {view === "dependencies" && <Dependencies />}
        {view === "resources" && <Resources can={can} />}
        {view === "approvals" && <Approvals can={can} />}
        {view === "assistant" && <Assistant can={can} />}
      </main>
    </>
  );
}
