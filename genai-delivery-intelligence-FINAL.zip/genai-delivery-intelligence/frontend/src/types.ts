// Shapes returned by the JSON API. All values are computed by the backend; the UI only displays them.
export interface Me { username: string; role: string; permissions: string[] }

export interface Overview {
  milestones_total: number; milestones_on_time: number; milestone_on_time_pct: number;
  open_dependencies: number; overdue_dependencies: number; pending_change_requests: number;
  overallocated_specialists: string[]; portfolio_margin_pct: number; planned_margin_pct: number;
  revenue_usd: number; cost_usd: number;
}

export interface ProgramRow {
  program_id: string; name: string; customer_id: string; milestones: number; milestones_on_time: number;
  milestone_on_time_pct: number; margin_pct: number; open_dependencies: number; overdue_dependencies: number;
  risk_score: number; risk_level: "HIGH" | "MEDIUM" | "LOW";
}

export interface CustomerRow {
  customer_id: string; customer: string; programs: string[];
  milestone_on_time_pct: number; margin_pct: number; max_program_risk: number;
}

export interface Reconcile { check: string; expected: number; actual: number; passed: boolean }

export interface Dependency {
  dependency_id: string; provider_program_id: string; provider_program: string; dependent_program_id: string;
  dependent_program: string; description: string; owner: string; due_date: string; status: string;
  days_overdue: number; downstream_milestone_id: string; downstream_milestone_status: string;
  escalation_priority: string; recommended_action: string;
}

export interface Specialist {
  specialist_id: string; name: string; role: string; is_key_role: boolean; total_pct: number;
  overallocated_pct: number; free_pct: number; allocations: { program_id: string; pct: number }[];
}

export interface ChangeRequest {
  change_id: string; program_id: string; program: string; customer: string; title: string; effort_days: number;
  schedule_impact_days: number; estimated_cost_usd: number; impact: string; recommendation: string;
  commitment_conflict: boolean; dependency_impact: boolean;
}

export interface Option {
  rank: number; description: string; feasible: boolean; requires_contractor: boolean;
  portfolio_risk_after_total: number; indicative_cost_impact_usd: number; margin_after_pct: number; preferred: boolean;
}

export interface Approval {
  id: number; kind: string; entity: string; summary: string; source: string; status: string;
  created_by: string; created_at: string; decided_by: string | null; decision_comment: string | null;
}

export interface Answer {
  direct_answer: string; supporting_evidence: string[]; calculated_results: string[]; references: string[];
  assumptions: string[]; recommended_actions: string[]; approval_requirements: string;
  policy_references: string[]; generation_mode: string; validation_errors?: string[];
}

export interface SimResult {
  label: string; margin_before_pct: number; margin_after_pct: number; indicative_cost_impact_usd: number;
  affected_programs: { program_name: string; customer: string; risk_before: number; risk_after: number }[];
  assumptions: string[]; approval_required: boolean;
}
