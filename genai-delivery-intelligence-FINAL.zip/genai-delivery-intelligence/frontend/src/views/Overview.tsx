import { useEffect, useState } from "react";
import { api, downloadFile, money, ApiError } from "../api";
import { Bars, Kpi } from "../charts";
import type { CustomerRow, Overview as OverviewData, ProgramRow, Reconcile } from "../types";

export default function Overview({ can }: { can: (p: string) => boolean }) {
  const [ov, setOv] = useState<OverviewData | null>(null);
  const [programs, setPrograms] = useState<ProgramRow[]>([]);
  const [customers, setCustomers] = useState<CustomerRow[]>([]);
  const [checks, setChecks] = useState<Reconcile[]>([]);
  const [message, setMessage] = useState<string | null>(null);
  const [files, setFiles] = useState<string[]>([]);

  useEffect(() => {
    Promise.all([
      api<OverviewData>("/api/overview"), api<ProgramRow[]>("/api/programs"),
      api<CustomerRow[]>("/api/customers"), api<Reconcile[]>("/api/reconciliation"),
    ]).then(([o, p, c, r]) => { setOv(o); setPrograms(p); setCustomers(c); setChecks(r); })
      .catch((e: unknown) => setMessage(e instanceof ApiError ? e.message : "Could not load overview"));
  }, []);

  const buildReports = async () => {
    try {
      const res = await api<{ files: string[] }>("/api/reports", { method: "POST" });
      setFiles(res.files);
      setMessage(null);
    } catch (e) {
      setMessage(e instanceof ApiError ? e.message : "Report build failed");
    }
  };

  if (!ov) return <p className="muted">{message ?? "Loading overview..."}</p>;
  const allPass = checks.every((c) => c.passed);

  return (
    <>
      {message && <div className="error">{message}</div>}
      <div className="panel">
        <h2>Baseline reconciliation (ORIGINAL INPUTS)</h2>
        <p className="muted">{allPass ? "All supplied figures reproduced by the synthetic dataset." : "Some checks fail. See the reconciliation list."}</p>
      </div>
      <div className="grid">
        <Kpi label="Milestones on time" value={`${ov.milestone_on_time_pct.toFixed(1)}%`} sub={`${ov.milestones_on_time} of ${ov.milestones_total} (original 71%)`} tone="warn" />
        <Kpi label="Open dependencies" value={String(ov.open_dependencies)} sub={`${ov.overdue_dependencies} overdue`} tone="bad" />
        <Kpi label="Pending change requests" value={String(ov.pending_change_requests)} />
        <Kpi label="Specialists above 100%" value={String(ov.overallocated_specialists.length)} sub={ov.overallocated_specialists.join(", ")} tone="bad" />
        <Kpi label="Portfolio margin" value={`${ov.portfolio_margin_pct.toFixed(1)}%`} sub={`plan ${ov.planned_margin_pct}%`} tone="warn" />
        <Kpi label="Revenue / cost" value={money(ov.revenue_usd)} sub={`cost ${money(ov.cost_usd)}`} />
      </div>
      <div className="panel">
        <h2>Program risk (deterministic score, 0 to 100)</h2>
        <Bars rows={programs.map((p) => ({ label: `${p.program_id} ${p.name}`.slice(0, 30), value: p.risk_score,
          tone: p.risk_level === "HIGH" ? "bad" : p.risk_level === "MEDIUM" ? "warn" : "ok" }))} />
        <table style={{ marginTop: 12 }}>
          <thead><tr><th>Program</th><th>Customer</th><th>Milestones on time</th><th>Margin</th><th>Overdue deps</th><th>Risk</th></tr></thead>
          <tbody>
            {programs.map((p) => (
              <tr key={p.program_id}>
                <td>{p.program_id} {p.name}</td><td>{p.customer_id}</td>
                <td>{p.milestones_on_time}/{p.milestones} ({p.milestone_on_time_pct}%)</td>
                <td>{p.margin_pct}%</td><td>{p.overdue_dependencies}</td>
                <td><span className={`tag ${p.risk_level === "HIGH" ? "bad" : p.risk_level === "MEDIUM" ? "warn" : "ok"}`}>{p.risk_level} {p.risk_score}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel">
        <h2>Customer commitments</h2>
        <table>
          <thead><tr><th>Customer</th><th>Programs</th><th>Milestones on time</th><th>Margin</th><th>Highest program risk</th></tr></thead>
          <tbody>
            {customers.map((c) => (
              <tr key={c.customer_id}><td>{c.customer}</td><td>{c.programs.join(", ")}</td>
                <td>{c.milestone_on_time_pct}%</td><td>{c.margin_pct}%</td><td>{c.max_program_risk}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="panel">
        <h2>Reports</h2>
        <p className="muted">Generated from the same database and analytics as this dashboard. Targets are labelled as targets.</p>
        {can("reports") ? (
          <>
            <button className="primary" onClick={buildReports}>Build reports</button>
            <div className="row" style={{ marginTop: 10 }}>
              {files.map((f) => (
                <button key={f} className="secondary" onClick={() => downloadFile(`/api/reports/${f}`, f).catch((e: unknown) => setMessage(String(e)))}>{f}</button>
              ))}
            </div>
          </>
        ) : <p className="muted">Your role cannot build or download reports.</p>}
      </div>
    </>
  );
}
