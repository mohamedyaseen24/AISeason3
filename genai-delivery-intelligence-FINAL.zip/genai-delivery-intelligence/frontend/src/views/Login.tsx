import { useState } from "react";
import type { FormEvent } from "react";
import { api, setToken, ApiError } from "../api";
import type { Me } from "../types";

export default function Login({ onLogin }: { onLogin: (me: Me) => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ token: string }>("/api/auth/login", { method: "POST", body: { username, password } });
      setToken(res.token);
      onLogin(await api<Me>("/api/me"));
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Sign-in failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="login panel">
      <h2>Sign in</h2>
      <form onSubmit={submit}>
        <div className="row"><label>Username<input value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" /></label></div>
        <div className="row"><label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" /></label></div>
        {error && <div className="error">{error}</div>}
        <button className="primary" type="submit" disabled={busy || !username || !password}>Sign in</button>
      </form>
      <p className="muted">Demo accounts are created by the init-db command.</p>
    </div>
  );
}
