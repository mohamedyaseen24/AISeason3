import { useState } from "react";
import { api, ApiError } from "../api";
import type { Answer } from "../types";

const SAMPLES = [
  "Which program should be prioritized first?",
  "Which specialists are overloaded?",
  "What are the overdue dependencies?",
  "Which change requests could delay the digital launch?",
  "Can a specialist be moved to another program?",
  "What is the recommended 90-day recovery strategy?",
];

export default function Assistant({ can }: { can: (p: string) => boolean }) {
  const [question, setQuestion] = useState(SAMPLES[0]);
  const [answer, setAnswer] = useState<Answer | null>(null);
  const [run, setRun] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const ask = async (q: string) => {
    setBusy(true); setError(null); setQuestion(q);
    try { setAnswer(await api<Answer>("/api/ask", { method: "POST", body: { question: q } })); }
    catch (e) { setError(e instanceof ApiError ? e.message : "Request failed"); }
    finally { setBusy(false); }
  };

  const runAgents = async () => {
    setBusy(true); setError(null);
    try {
      const r = await api<{ status: string; findings: unknown[]; approval_ids: number[] }>("/api/agent-runs", { method: "POST", body: { question } });
      setRun(`Workflow ${r.status}: ${r.findings.length} recommendations queued for approval (IDs ${r.approval_ids.join(", ") || "none"}).`);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Workflow failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="panel">
      <h2>Leadership assistant</h2>
      <p className="muted">Every answer is built from deterministic tools. Labels show what is a FACT, an AI ANALYSIS, or an ASSUMPTION.</p>
      <div className="chips">{SAMPLES.map((s) => <button key={s} className="secondary" onClick={() => ask(s)} disabled={busy}>{s}</button>)}</div>
      <div className="row">
        <label style={{ flex: 1 }}>Your question
          <textarea value={question} maxLength={500} onChange={(e) => setQuestion(e.target.value)} />
        </label>
      </div>
      <div className="row">
        <button className="primary" onClick={() => ask(question)} disabled={busy || question.trim().length < 3}>Ask</button>
        {can("agent_run") && <button className="secondary" onClick={runAgents} disabled={busy}>Run agent workflow (queues approvals)</button>}
      </div>
      {error && <div className="error">{error}</div>}
      {run && <p className="muted">{run}</p>}
      {answer && (
        <div className="answer">
          <p><strong>{answer.direct_answer}</strong> <span className="tag">{answer.generation_mode}</span></p>
          {answer.validation_errors && <p className="muted">AI text rejected by validation; showing deterministic answer. Reasons: {answer.validation_errors.join("; ")}</p>}
          <h3>Supporting evidence</h3><ul>{answer.supporting_evidence.map((e) => <li key={e}>{e}</li>)}</ul>
          {answer.calculated_results.length > 0 && <><h3>Calculated results</h3><ul>{answer.calculated_results.map((e) => <li key={e}>{e}</li>)}</ul></>}
          {answer.assumptions.length > 0 && <><h3>Assumptions</h3><ul>{answer.assumptions.map((e) => <li key={e}>{e}</li>)}</ul></>}
          {answer.recommended_actions.length > 0 && <><h3>Recommended actions</h3><ul>{answer.recommended_actions.map((e) => <li key={e}>{e}</li>)}</ul></>}
          <h3>Approval</h3><p className="muted">{answer.approval_requirements}</p>
          <h3>Policy references</h3><ul>{answer.policy_references.map((e) => <li key={e}>{e}</li>)}</ul>
        </div>
      )}
    </div>
  );
}
