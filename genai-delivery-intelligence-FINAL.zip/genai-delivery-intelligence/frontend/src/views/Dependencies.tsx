import { useEffect, useMemo, useState } from "react";
import { api, toneForPriority } from "../api";
import type { Dependency, ProgramRow } from "../types";

export default function Dependencies() {
  const [rows, setRows] = useState<Dependency[]>([]);
  const [programs, setPrograms] = useState<ProgramRow[]>([]);
  const [priority, setPriority] = useState("");
  const [program, setProgram] = useState("");
  const [dueBefore, setDueBefore] = useState("");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<ProgramRow[]>("/api/programs").then(setPrograms).catch(() => setPrograms([]));
  }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    if (priority) params.set("priority", priority);
    if (program) params.set("program", program);
    if (dueBefore) params.set("due_before", dueBefore);
    api<Dependency[]>(`/api/dependencies?${params.toString()}`)
      .then((r) => { setRows(r); setError(null); })
      .catch((e: Error) => setError(e.message));
  }, [priority, program, dueBefore]);

  const overdue = useMemo(() => rows.filter((r) => r.status === "OVERDUE").length, [rows]);

  return (
    <div className="panel">
      <h2>Open dependencies ({rows.length}) - overdue: {overdue}</h2>
      <div className="row">
        <label>Escalation priority
          <select value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="">All</option><option>P1 CRITICAL</option><option>P2 HIGH</option><option>P3 MEDIUM</option><option>NONE</option>
          </select>
        </label>
        <label>Program
          <select value={program} onChange={(e) => setProgram(e.target.value)}>
            <option value="">All programs</option>
            {programs.map((p) => <option key={p.program_id} value={p.program_id}>{p.program_id} {p.name}</option>)}
          </select>
        </label>
        <label>Due on or before
          <input type="date" value={dueBefore} onChange={(e) => setDueBefore(e.target.value)} />
        </label>
      </div>
      {error && <div className="error">{error}</div>}
      <table>
        <thead>
          <tr><th>ID</th><th>Provider to dependent</th><th>Description</th><th>Owner</th><th>Due</th><th>Days overdue</th><th>Downstream milestone</th><th>Priority</th><th>Recommended action</th></tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.dependency_id}>
              <td>{r.dependency_id}</td>
              <td>{r.provider_program_id} to {r.dependent_program_id}</td>
              <td>{r.description}</td><td>{r.owner}</td><td>{r.due_date}</td>
              <td>{r.days_overdue}</td>
              <td>{r.downstream_milestone_id} <span className="muted">({r.downstream_milestone_status})</span></td>
              <td><span className={`tag ${toneForPriority(r.escalation_priority)}`}>{r.escalation_priority}</span></td>
              <td className="muted">{r.recommended_action}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
