// Dependency-free SVG charts. Values come from the API; nothing is calculated in the browser.
export interface BarRow { label: string; value: number; tone?: "bad" | "warn" | "ok" }

export function Bars({ rows, max = 100, unit = "" }: { rows: BarRow[]; max?: number; unit?: string }) {
  const width = 520, rowH = 26, labelW = 170, valueW = 60;
  const barMax = width - labelW - valueW;
  const height = rows.length * rowH + 4;
  return (
    <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="bar chart" className="bars">
      {rows.map((r, i) => {
        const w = Math.max(0, Math.min(1, r.value / max)) * barMax;
        const fill = r.tone === "bad" ? "#b42318" : r.tone === "warn" ? "#b54708" : "#1d4ed8";
        return (
          <g key={`${r.label}-${i}`} transform={`translate(0,${i * rowH})`}>
            <text x={0} y={17} fontSize="12" fill="#101828">{r.label}</text>
            <rect x={labelW} y={5} width={barMax} height={14} rx={3} fill="#eef0f3" />
            <rect x={labelW} y={5} width={w} height={14} rx={3} fill={fill} />
            <text x={labelW + barMax + 6} y={17} fontSize="12" fill="#101828">{r.value}{unit}</text>
          </g>
        );
      })}
    </svg>
  );
}

export function Kpi({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: "bad" | "warn" | "ok" }) {
  const color = tone === "bad" ? "var(--bad)" : tone === "warn" ? "var(--warn)" : undefined;
  return (
    <div className="card">
      <div className="label">{label}</div>
      <div className="value" style={{ color }}>{value}</div>
      {sub && <div className="sub">{sub}</div>}
    </div>
  );
}
