---
title: Change Request Procedure (placeholder)
doc_type: SOP
scope: ALL
category: CHANGE_REQUEST
status: PLACEHOLDER
effective_date: 2026-01-01
version: 0.1
---
# Change Request Procedure

> SYNTHETIC PLACEHOLDER. This is illustrative text written for the demo. It is NOT an approved company policy. Replace with the organisation's approved document before any use.

## Impact assessment
Every change request needs an effort estimate, a schedule impact, a dependency impact and a statement of commitment conflict before a decision.

## Decision
Changes with high schedule impact or commitment conflict are deferred or returned for more information. Only an authorised decision-maker may reject a change.

## Recording
Every decision is recorded with its rationale in the approval records.
