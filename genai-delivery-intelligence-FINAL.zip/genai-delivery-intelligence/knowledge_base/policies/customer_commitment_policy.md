---
title: Customer Commitment Policy (placeholder)
doc_type: POLICY
scope: ALL
category: CUSTOMER_COMMITMENT
status: PLACEHOLDER
effective_date: 2026-01-01
version: 0.1
---
# Customer Commitment Policy

> SYNTHETIC PLACEHOLDER. This is illustrative text written for the demo. It is NOT an approved company policy. Replace with the organisation's approved document before any use.

## Protecting committed milestones
Milestones with a contractual or launch date are protected. Scope changes that threaten a protected milestone are deferred unless the customer agrees a new date in writing.

## Live support
Live support coverage must not be reduced to free capacity for delivery work.

## Communication
Customers are informed of any forecast change to a protected milestone within two business days of identification.
