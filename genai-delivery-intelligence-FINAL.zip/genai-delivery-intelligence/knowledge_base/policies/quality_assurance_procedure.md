---
title: Delivery Quality Assurance Procedure (placeholder)
doc_type: SOP
scope: ALL
category: QUALITY
status: PLACEHOLDER
effective_date: 2026-01-01
version: 0.1
---
# Delivery Quality Assurance Procedure

> SYNTHETIC PLACEHOLDER. This is illustrative text written for the demo. It is NOT an approved company policy. Replace with the organisation's approved document before any use.

## Test capacity
Test leads may not be allocated above 100%. Peak-season load testing requires a named test lead and environment.

## Release gates
No release proceeds without a completed test cycle signed off by the test lead.

## Defect review
Escaped defects are reviewed within five working days and reported to the portfolio review.
