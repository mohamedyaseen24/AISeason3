---
title: Dependency Escalation Guideline (placeholder)
doc_type: GUIDELINE
scope: ALL
category: DEPENDENCY
status: PLACEHOLDER
effective_date: 2026-01-01
version: 0.1
---
# Dependency Escalation Guideline

> SYNTHETIC PLACEHOLDER. This is illustrative text written for the demo. It is NOT an approved company policy. Replace with the organisation's approved document before any use.

## Overdue dependencies
A dependency overdue by 30 days or more is escalated to the provider program sponsor within two business days.

## Ownership
Every open dependency has a named owner and a committed revised date.

## Downstream impact
When an overdue dependency blocks a milestone, the milestone forecast is re-baselined and the customer is informed.
