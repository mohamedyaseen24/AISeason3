# Multi-Program Delivery Intelligence Platform

Problem Statement 05: multi-program delivery predictability and resource prioritisation.

**All customers, programs, people, milestones and dependencies are FICTIONAL.** The supplied business figures are
preserved exactly and checked by `python -m app.cli reconcile` (10 of 10 pass). The policy documents are SYNTHETIC
PLACEHOLDERS and must be replaced with approved organisational policies before any use.

## Quick start

```bash
# 1. Backend (standard library + numpy, openpyxl, reportlab, pypdf)
cd backend
pip install -r requirements.txt
python -m app.cli init-db          # synthetic database, demo accounts (written to data/demo_credentials.local.txt)
python -m app.cli ingest-kb        # policy knowledge base (placeholders)
python -m app.cli reconcile        # 10/10 checks against the original business inputs
python -m app.cli reports          # decision brief PDF, 90-day plan PDF, Excel workbook
python -m unittest discover -s tests -t .    # 52 tests
python -m app.cli serve            # http://127.0.0.1:8000

# 2. Frontend (React + TypeScript, needs Node 18+)
cd ../frontend
npm install
npm run build                      # writes dist/, served by the backend
```

Open http://127.0.0.1:8000 and sign in with a demo account. Passwords are random and written to
`data/demo_credentials.local.txt` by `init-db`. Change or delete that file before any shared use.

## Roles

| Role | Can do |
|---|---|
| VIEWER | Read dashboards, dependencies, scope, approvals, policies |
| ANALYST | VIEWER plus simulations, assistant questions, agent runs, reports |
| APPROVER (portfolio leader) | ANALYST plus recording approve or reject decisions |
| ADMIN | APPROVER plus user management and policy re-ingestion |

AI actors can create recommendations but cannot decide them. Every decision is written to the audit log.

## API (JSON, Bearer token)

| Method | Path | Role |
|---|---|---|
| GET | /api/health | public |
| POST | /api/auth/login, /api/auth/logout | public / any |
| GET | /api/me, /api/overview, /api/reconciliation, /api/programs, /api/customers, /api/risks | VIEWER |
| GET | /api/dependencies (filters: program, priority, due_before) | VIEWER |
| GET | /api/specialists, /api/reallocation/{SP-nn}, /api/change-requests (filters: impact, recommendation) | VIEWER |
| GET | /api/sensitivity, /api/policies?q=, /api/agent-runs | VIEWER |
| GET | /api/approvals?status= | VIEWER |
| POST | /api/approvals/{id}/decide | APPROVER |
| POST | /api/simulate | ANALYST |
| POST | /api/ask | ANALYST |
| POST | /api/agent-runs | ANALYST |
| POST | /api/reports, GET /api/reports/{file} | ANALYST |
| POST | /api/policies/ingest, GET/POST /api/admin/users | ADMIN |

## Security controls (implemented and tested)

- PBKDF2-SHA256 password hashing (200,000 iterations), constant-time comparison, timing-equalised failed logins.
- Session tokens stored only as SHA-256 hashes, 8-hour expiry, revocable on logout.
- Role-based permission checks on every route. Unauthenticated requests get 401, insufficient roles get 403.
- Input validation: question length and character allow-list, JSON body size limit (64 KB), scenario bounds,
  composite step limits, username and password rules, file-name validation for downloads.
- Rate limits: login attempts, questions and agent runs (token buckets).
- Strict response headers: CSP `default-src 'self'`, `X-Frame-Options: DENY`, `nosniff`, `no-store` on API responses.
- Path-traversal protection on static files and report downloads.
- Audit log: logins, failed logins, AI queries, recommendations created, decisions, user creation.

## GenAI safeguards

- Every number and ID in AI text must appear in the deterministic facts it was given; otherwise the text is rejected
  and the deterministic answer is shown (`generation_mode: deterministic_fallback`).
- AI output that claims an approval or execution is rejected. `approval_required` must be true.
- Policy text is retrieved as data inside `<untrusted_policy_excerpt>` tags. Documents matching prompt-injection
  patterns are quarantined at ingest and never retrieved.
- Agent findings must cite tool-call IDs and evidence. Findings without them are dropped before approval.
- Simulations run on in-memory copies. Tests confirm neither the snapshot nor the database changes.

## LLM configuration (optional)

Set `LLM_PROVIDER` (`openai_compatible` or `anthropic`), `LLM_MODEL`, `LLM_API_KEY` and, if needed, `LLM_BASE_URL`
in the environment. With no provider, the platform runs fully deterministically. Keys are never stored in code.

## Architecture

```
SQLite (synthetic seed, users, sessions, approvals, audit, agent runs, policy index)
  -> services/snapshot          load and derive (overdue, days overdue)
  -> services/portfolio, risk, resource, dependency, scope   deterministic analytics
  -> services/simulation        what-if on in-memory copies, reallocation option search
  -> services/report            PDF and Excel from the same data as the dashboard
  -> services/sensitivity       risk-weight sensitivity (not calibration)
  -> genai/tools                schema-validated tools returning real data
  -> genai/agents               five agents: risk, resource, dependency, scope, portfolio
  -> genai/orchestrator         stateful graph: route -> agents -> validate -> approval checkpoint
  -> genai/rag                  parse (md, txt, pdf, docx), clean, chunk, metadata, embed, quarantine, search
  -> genai/decision_assistant   answers with FACT / AI ANALYSIS / ASSUMPTION labels
  -> server                     JSON API and static host (standard library)
frontend (React + TypeScript): overview, dependencies, resources and scope, approvals, assistant
```

## Known limitations

- The embedding is a deterministic lexical hash, not a neural model. Retrieval is good for the placeholder policies
  but should be upgraded before real use.
- Reallocation options within one program tie on portfolio risk, because capacity is scored per specialist. Ties are
  broken by cost. This is stated in the output.
- Risk weights are judgement-based. Sensitivity analysis shows the ranking is stable within +/-25%. Calibration
  against historical outcomes is not possible without that data.
- Approved decisions are recorded but not applied to the baseline automatically. Applying a decision is a separate,
  deliberate step that is not implemented.
- See `docs/STATUS.md` for what was verified in this build and what could not be installed or executed.
