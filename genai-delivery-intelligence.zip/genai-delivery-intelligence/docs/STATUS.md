# Build status

## Verified in the build environment

| Area | Evidence |
|---|---|
| Original figures reproduced | `python -m app.cli reconcile`: 10/10 pass |
| Deterministic analytics | risk scoring, dependency escalation, scope classification, capacity (unit tests) |
| Reallocation search and simulation | feasibility, ranking, no baseline writes (tests and file-hash check) |
| Authentication and sessions | login, logout revocation, generic failure messages (HTTP tests) |
| Role-based access | viewer, analyst, approver and admin restrictions (HTTP tests) |
| Approval workflow | AI-created PENDING records; AI cannot decide; leader decision; no double decision (tests) |
| Input validation and limits | injection characters, length, JSON size, scenario bounds, traversal, file names (tests) |
| Rate limits | login, questions and agent runs (tests) |
| Structured output validation | grounding of IDs and numbers, approval flag, claimed approvals (tests) |
| LLM fallback | valid output accepted, ungrounded or failed output falls back (tests with scripted provider) |
| RAG | parsing of md, txt, pdf and docx; quarantine of injected text; metadata filters; noise floor (tests) |
| Agent orchestration | routing, tool validation, approval checkpoint, persisted run state (tests) |
| Reports | PDF (decision brief, 90-day plan) and Excel workbook generated and downloaded (tests and live run) |
| Live server | started as a process, exercised with curl: health, static app, login, ask, agent run, approvals, PDF download |
| Frontend type check | `tsc` passes with an offline stand-in for React type definitions (see note below) |
| Frontend bundle | esbuild bundles the React app (217 KB minified including React); bundle parses |

## Written but limited by the environment

- **React types.** `@types/react` could not be installed offline. The type check used a shim with matching
  signatures for the APIs the code uses. Running `npm install` gives the real types; run `npm run typecheck` then.
- **Frontend in a browser.** The bundle builds and the server serves it, but no browser was available to click
  through the screens. Visual checks are still needed.
- **LLM providers.** The adapters (OpenAI-compatible and Anthropic) are implemented with standard-library HTTP,
  but no network was available, so they were tested only with a scripted provider. Test with a real key before use.
- **Charts.** Dependency-free SVG bars, not Recharts. Only bar charts are included; trend charts need history data,
  which does not exist yet.

## Replaced because the packages could not be installed

| Planned | Built instead | Upgrade path |
|---|---|---|
| FastAPI and Pydantic | Standard-library HTTP server with the same JSON contract | Move routes to FastAPI when installable |
| LangGraph | Small stateful graph with nodes, edges, conditional routing and persisted state | Map nodes to LangGraph when installable |
| Chroma or FAISS | Numpy vector search over SQLite | Swap the store behind `rag.search` |
| Neural embedding model | Deterministic hashed n-gram embedding | Set `EMBEDDING_MODEL` and replace `embedder.py` |

## Not done, and why

1. **PostgreSQL and SQLAlchemy.** No database driver or ORM can be installed here. The schema is SQLite-specific
   (CHECK constraints, PRAGMA). Porting needs a driver, a migration tool, and a live Postgres to test against.
2. **Calibration of risk weights.** Needs historical delivery outcomes, which this project does not have. The
   sensitivity analysis (`python -m app.cli sensitivity`) shows the ranking is stable under +/-25% weight changes.
   This is not calibration.
3. **Applying approved decisions.** Approved decisions are recorded, not executed. Writing them to the baseline needs
   a separate, explicitly authorised step and a design for versioned baselines. Deliberately not built.
4. **Policy documents.** The five policies are synthetic placeholders. Replace them with approved documents and run
   `python -m app.cli ingest-kb`. Until then, the assistant reports that policy coverage is placeholder-only.
5. **Multi-factor login, password reset, email notifications, and a user interface for admin tasks.** Admin tasks
   are available through the API only.
6. **Production hardening.** Run behind TLS with a reverse proxy, move the rate limiter to shared storage, and
   manage secrets through a secret store. The server binds to 127.0.0.1 by default.

## Figure provenance

- ORIGINAL INPUT: `ORIGINAL_BASELINE` in `backend/app/data/synthetic_portfolio.py`. Do not edit.
- SYNTHETIC: all other records in that file, and the policy documents in `knowledge_base/`.
- FACT: values computed by `services/*` from the database.
- AI ANALYSIS: rule-based text in `genai/decision_assistant.py`, agent findings, and any validated LLM text.
- ASSUMPTION: stated in each response's `assumptions` field.
- APPROVED DECISION: only records in the approval table with status APPROVED and a named decider.
- TARGET: `TARGET_*` values in `config.py`. Proposals, never achieved results.
